/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from "react";
import { 
  Plus, Check, Star, ShieldCheck, HelpCircle, ArrowRight, Phone, Mail, MapPin, 
  ChevronDown, MessageSquare, Anchor, Ship, FileText, Award, Layers, Sparkles, 
  CheckCircle, Trash2, Calendar, FileCheck, Globe, ShoppingCart, User, Landmark, Info
} from "lucide-react";

import Header from "./components/Header";
import ProductCatalog from "./components/ProductCatalog";
import TeamAndMap from "./components/TeamAndMap";
import InteractiveGlobe from "./components/InteractiveGlobe";
import Footer from "./components/Footer";
import { PrivacyPolicyModal, TermsConditionsModal } from "./components/LegalModals";

import { 
  PRODUCT_CATEGORIES, 
  CUSTOM_SERVICES, 
  WHY_CHOOSE_US_ITEMS, 
  QA_STEPS, 
  PACKAGING_SIZES, 
  PACKAGING_TYPES, 
  TARGET_BUYERS, 
  REVIEWS, 
  FAQS,
  Product 
} from "./data";

interface RfqItem {
  product: Product;
  quantityValue: number;
  quantityUnit: string;
  packagingType: string;
}

export default function App() {
  const [activeTab, setActiveTab] = useState<string>("home");
  const [rfqItems, setRfqItems] = useState<RfqItem[]>([]);
  const [faqOpenIndex, setFaqOpenIndex] = useState<number | null>(null);
  
  // Modals
  const [isPrivacyOpen, setIsPrivacyOpen] = useState(false);
  const [isTermsOpen, setIsTermsOpen] = useState(false);

  // Quote Request Form Fields State
  const [formName, setFormName] = useState("");
  const [formCompany, setFormCompany] = useState("");
  const [formCountry, setFormCountry] = useState("");
  const [formEmail, setFormEmail] = useState("");
  const [formPhone, setFormPhone] = useState("");
  const [formWhatsApp, setFormWhatsApp] = useState("");
  const [formDestinationPort, setFormDestinationPort] = useState("");
  const [formCustomMessage, setFormCustomMessage] = useState("");
  
  // Sourcing items requested in the form
  const [sourcingListText, setSourcingListText] = useState("");
  const [packageRequirementsText, setPackageRequirementsText] = useState("");

  // Submission Management State
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submitSuccess, setSubmitSuccess] = useState(false);
  const [quoteReference, setQuoteReference] = useState("");

  // Sync draft cart items into the form fields text area automatically!
  useEffect(() => {
    if (rfqItems.length > 0) {
      const draftList = rfqItems.map(
        item => `• ${item.product.name} (Qty: ${item.quantityValue} ${item.quantityUnit}, Packaging: ${item.packagingType})`
      ).join("\n");
      setSourcingListText(draftList);

      const uniquePkgs = Array.from(new Set(rfqItems.map(i => i.packagingType)));
      setPackageRequirementsText(`Estimated total load packaged via: ${uniquePkgs.join(", ")}`);
    } else {
      setSourcingListText("");
      setPackageRequirementsText("");
    }
  }, [rfqItems]);

  // Sourcing Cart State Helpers
  const addRfqItem = (product: Product) => {
    const exists = rfqItems.find(item => item.product.id === product.id);
    if (!exists) {
      const newItem: RfqItem = {
        product,
        quantityValue: 250, // Default B2B MOQ starting point
        quantityUnit: "kg",
        packagingType: "25kg Bulk Bag"
      };
      setRfqItems([...rfqItems, newItem]);
    }
  };

  const removeRfqItem = (id: string) => {
    setRfqItems(rfqItems.filter(item => item.product.id !== id));
  };

  const updateRfqItem = (id: string, qty: number, unit: string, pkg: string) => {
    setRfqItems(rfqItems.map(item => {
      if (item.product.id === id) {
        return {
          ...item,
          quantityValue: qty,
          quantityUnit: unit,
          packagingType: pkg
        };
      }
      return item;
    }));
  };

  // Submission handler
  const handleFormSubmission = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formName || !formEmail || !formCompany || !formCountry) {
      alert("Please fill in required fields (Name, Company, Country, Email).");
      return;
    }

    setIsSubmitting(true);
    
    // Simulate premium B2B contract confirmation ticketing delay
    setTimeout(() => {
      const generatedRef = "KE-REQ-2026-" + Math.floor(1000 + Math.random() * 9000);
      setQuoteReference(generatedRef);
      setIsSubmitting(false);
      setSubmitSuccess(true);
      
      // Clear Form state but keep draft cargo list as historical receipt
      setFormName("");
      setFormPhone("");
      setFormWhatsApp("");
      setFormDestinationPort("");
      setFormCustomMessage("");
    }, 1500);
  };

  const resetFormState = () => {
    setSubmitSuccess(false);
    setRfqItems([]); // Clear cart upon successful submittal to reset fresh
  };

  // Direct scrolls or Tabs Jump
  const handleOpenQuoteForm = () => {
    setActiveTab("contact");
    setTimeout(() => {
      const formEl = document.getElementById("quote_form_section");
      if (formEl) {
        formEl.scrollIntoView({ behavior: "smooth" });
      }
    }, 100);
  };

  return (
    <div className="min-h-screen bg-[#F7F9F8] flex flex-col justify-between antialiased selection:bg-[#1F6B3A] selection:text-white pb-0">
      
      {/* Sticky Header with integrated RFQ Sidebar Cart */}
      <Header 
        activeTab={activeTab} 
        setActiveTab={setActiveTab} 
        rfqItems={rfqItems}
        removeRfqItem={removeRfqItem}
        updateRfqItem={updateRfqItem}
        onOpenQuoteForm={handleOpenQuoteForm}
      />

      {/* Main Content Areas based on tabs */}
      <main className="flex-grow">
        
        {/* VIEW: HOME PAGE */}
        {activeTab === "home" && (
          <div className="space-y-16 pb-20">
            
            {/* 1. HERO SECTION WITH INTEGRATED ROTATING 3D GLOBE */}
            <section className="relative overflow-hidden bg-white border-b border-emerald-950/5 pt-12 lg:pt-16 pb-16">
              {/* Radial atmospheric mesh styling */}
              <div className="absolute top-0 right-0 w-96 h-96 bg-emerald-500/5 rounded-full blur-3xl pointer-events-none" />
              <div className="absolute top-1/2 left-0 w-80 h-80 bg-amber-500/5 rounded-full blur-3xl pointer-events-none" />

              <div className="max-w-7xl mx-auto px-4 md:px-8 grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
                
                {/* Hero Words Column (Col 7) */}
                <div className="lg:col-span-7 space-y-6 md:space-y-8 z-10 text-left">
                  
                  {/* Premium floating trust badges */}
                  <div className="flex flex-wrap gap-2.5 items-center select-none">
                    <span className="inline-flex items-center gap-1 px-3 py-1 bg-[#1F6B3A]/10 text-[#1F6B3A] text-xs font-semibold rounded-full border border-[#1F6B3A]/25">
                      <Award className="w-3.5 h-3.5 text-[#D4A017] fill-[#D4A017]" /> Merchant Exporter
                    </span>
                    <span className="inline-flex items-center gap-1 px-3 py-1 bg-amber-500/10 text-amber-950 text-xs font-semibold rounded-full border border-amber-500/20">
                      <Star className="w-3.5 h-3.5 fill-[#D4A017] text-[#D4A017]" /> 100% Sourced In India
                    </span>
                  </div>

                  {/* Headline: Strict matching user guidelines */}
                  <h1 className="text-3.5xl sm:text-4.5xl lg:text-5xl font-extrabold font-display leading-tight tracking-tight text-slate-900">
                    India's Trusted Exporter of <span className="bg-linear-to-r from-[#1F6B3A] to-emerald-800 bg-clip-text text-transparent">Dehydrated Vegetable, Fruit, Herbal</span> & Agricultural Powders
                  </h1>

                  {/* Subheadline: Strict matching user guidelines */}
                  <p className="text-sm md:text-base leading-relaxed text-slate-600 font-sans max-w-3xl">
                    KanhaiyaExim specializes in sourcing and exporting premium dehydrated powders including Moringa Powder, Garlic Powder, Onion Powder, Beetroot Powder, Fruit Powders, Herbal Powders, Tea Powders, Coffee Powders and customized agricultural ingredients for global buyers, importers, distributors, food manufacturers, nutraceutical brands and private-label companies.
                  </p>

                  {/* Interactive Trust Quick Badges */}
                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 pt-1 pb-2 border-t border-b border-slate-150/85">
                    <div className="space-y-1">
                      <span className="block font-mono font-bold text-[#1F6B3A] text-sm tracking-wide">50+ INGREDIENTS</span>
                      <span className="block text-[10px] text-slate-500 uppercase font-sans">Full catalog range</span>
                    </div>
                    <div className="space-y-1">
                      <span className="block font-mono font-bold text-[#1F6B3A] text-sm tracking-wide">JNPT EXPORT PORT</span>
                      <span className="block text-[10px] text-slate-500 uppercase font-sans">Direct West Coast shipping</span>
                    </div>
                    <div className="space-y-1">
                      <span className="block font-mono font-bold text-[#1F6B3A] text-sm tracking-wide">IEC REGISTERED</span>
                      <span className="block text-[10px] text-slate-500 uppercase font-sans">DAVPT2930Q Certified</span>
                    </div>
                    <div className="space-y-1">
                      <span className="block font-mono font-bold text-[#1F6B3A] text-sm tracking-wide">HACCP COMPLIANT</span>
                      <span className="block text-[10px] text-slate-500 uppercase font-sans">Strict manufacturing partners</span>
                    </div>
                  </div>

                  {/* CTAs */}
                  <div className="flex flex-col sm:flex-row gap-3.5 pt-2">
                    <button
                      id="hero_cb_quote"
                      onClick={handleOpenQuoteForm}
                      className="px-6 py-3.5 bg-linear-to-r from-[#1F6B3A] to-emerald-800 hover:to-emerald-700 text-white hover:bg-emerald-900 border-b border-emerald-950/20 rounded-xl text-xs font-semibold uppercase tracking-wider font-display flex items-center justify-center gap-1.5 shadow-md hover:shadow-lg transition cursor-pointer"
                    >
                      <FileCheck className="w-4 h-4 text-[#D4A017]" /> Request Quote
                    </button>

                    <button
                      id="hero_cb_explore"
                      onClick={() => { setActiveTab("products"); window.scrollTo({ top: 300, behavior: "smooth" }); }}
                      className="px-6 py-3.5 bg-white hover:bg-slate-50 border border-slate-300 rounded-xl text-xs font-semibold uppercase tracking-wider font-display text-slate-700 transition flex items-center justify-center gap-1 cursor-pointer hover:border-[#1F6B3A]"
                    >
                      Explore Products <ArrowRight className="w-3.5 h-3.5 text-[#1F6B3A]" />
                    </button>

                    <button
                      id="hero_cb_contact"
                      onClick={() => { setActiveTab("contact"); window.scrollTo({ top: 0, behavior: "smooth" }); }}
                      className="px-6 py-3.5 bg-emerald-50/50 hover:bg-emerald-50 text-emerald-900 border border-emerald-900/10 rounded-xl text-xs font-semibold uppercase tracking-wider font-display flex items-center justify-center gap-1 cursor-pointer transition"
                    >
                      Contact Us
                    </button>
                  </div>
                </div>

                {/* Rotating Globe Column (Col 5) */}
                <div className="lg:col-span-5 flex justify-center items-center">
                  <div className="relative w-full max-w-[460px] xl:max-w-none">
                    {/* Background rings */}
                    <div className="absolute inset-0 bg-radial from-transparent to-transparent pointer-events-none border border-dashed border-slate-200 rounded-full scale-110" />
                    <InteractiveGlobe />
                  </div>
                </div>

              </div>
            </section>

            {/* 2. ABOUT KANHAIYAEXIM */}
            <section className="max-w-7xl mx-auto px-4 md:px-8">
              <div className="bg-white border border-emerald-900/10 rounded-3xl p-8 md:p-12 shadow-xs grid grid-cols-1 lg:grid-cols-2 gap-10 items-center relative overflow-hidden">
                <div className="absolute top-0 right-0 w-48 h-full bg-linear-to-l from-[#1F6B3A]/5 to-transparent pointer-events-none" />
                
                <div className="space-y-6">
                  <div>
                    <span className="text-xs font-mono font-bold tracking-widest text-[#D4A017] uppercase">ESTABLISHED EXPORT CREDIBILITY</span>
                    <h3 className="text-2.5xl md:text-3.5xl font-extrabold tracking-tight font-display text-slate-900 mt-0.5">
                      Merchant Exporter & Sourcing Partner
                    </h3>
                  </div>

                  <p className="text-sm text-slate-605 leading-relaxed font-sans">
                    KanhaiyaExim is an India-based merchant exporter and sourcing partner specializing in dehydrated vegetable powders, fruit powders, herbal powders, tea powders, coffee powders and customized agricultural ingredients.
                  </p>

                  <p className="text-sm text-slate-600 leading-relaxed font-sans">
                    We work closely with trusted manufacturing partners and quality-focused suppliers to provide reliable sourcing solutions for importers, distributors, wholesalers, food manufacturers, nutraceutical companies and private-label brands worldwide.
                  </p>

                  <div className="bg-emerald-50/50 rounded-2xl p-4 border border-emerald-950/5 space-y-1">
                    <span className="text-xs font-bold text-[#1F6B3A] uppercase tracking-wider font-display">Our Corporate Mission</span>
                    <p className="text-xs text-emerald-950/80 leading-relaxed font-sans italic">
                      "Our mission is to connect global buyers with premium-quality Indian products while maintaining transparency, reliability and long-term business partnerships."
                    </p>
                  </div>
                </div>

                <div className="space-y-5">
                  <h4 className="text-xs font-mono font-bold uppercase tracking-wider text-slate-400 border-b border-slate-100 pb-2">
                    Key Trade Certifications
                  </h4>
                  
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div className="bg-[#F7F9F8] rounded-xl p-4 border border-slate-200">
                      <ShieldCheck className="w-7 h-7 text-[#1F6B3A] mb-2" />
                      <span className="block font-bold text-slate-800 text-sm">IEC Registered</span>
                      <span className="block text-[11px] text-slate-500 mt-0.5">DAVPT2930Q | Valid for global port customs</span>
                    </div>

                    <div className="bg-[#F7F9F8] rounded-xl p-4 border border-slate-200">
                      <Landmark className="w-7 h-7 text-[#D4A017] mb-2" />
                      <span className="block font-bold text-slate-800 text-sm">GST Authorized</span>
                      <span className="block text-[11px] text-slate-500 mt-0.5">27DAVPT2930Q1ZK Registry verified</span>
                    </div>

                    <div className="bg-[#F7F9F8] rounded-xl p-4 border border-slate-200">
                      <Ship className="w-7 h-7 text-[#1F6B3A] mb-2" />
                      <span className="block font-bold text-slate-800 text-sm">JNPT Port Partner</span>
                      <span className="block text-[11px] text-slate-500 mt-0.5">Rapid dispatch from Nhava Sheva, Mumbai</span>
                    </div>

                    <div className="bg-[#F7F9F8] rounded-xl p-4 border border-slate-200">
                      <Layers className="w-7 h-7 text-[#D4A017] mb-2" />
                      <span className="block font-bold text-slate-800 text-sm">Custom Packaging</span>
                      <span className="block text-[11px] text-slate-500 mt-0.5">Premium bulk drums or private retail packs</span>
                    </div>
                  </div>
                </div>

              </div>
            </section>

            {/* 3. CORE BENEFITS / WHY CHOOSE US COLLATERAL */}
            <section className="max-w-7xl mx-auto px-4 md:px-8">
              <div className="text-center max-w-3xl mx-auto mb-12">
                <span className="text-xs font-mono font-bold tracking-widest text-[#D4A017] uppercase block mb-1">STRICT B2B STANDARDS</span>
                <h3 className="text-3xl font-extrabold tracking-tight text-slate-900 font-display">
                  Sourcing Safeguards & Trade Protections
                </h3>
                <p className="text-sm font-sans text-slate-505 mt-2">
                  We bridge the gap between rural Indian agriculture and stringent international food safety guidelines with seamless document audits.
                </p>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                {WHY_CHOOSE_US_ITEMS.map((item, idx) => (
                  <div key={item.title} className="bg-white border border-slate-200 hover:border-[#1F6B3A] rounded-2xl p-5 shadow-2xs hover:shadow-md transition duration-300 flex flex-col justify-between group">
                    <div className="space-y-3">
                      <div className="w-9 h-9 rounded-xl bg-emerald-50 text-[#1F6B3A] font-bold font-mono text-xs flex items-center justify-center shrink-0 border border-emerald-950/5 shadow-2xs">
                        0{idx+1}
                      </div>
                      <h4 className="text-sm font-bold text-slate-900 font-sans group-hover:text-[#1F6B3A] transition">
                        {item.title}
                      </h4>
                      <p className="text-xs text-slate-500 leading-relaxed font-sans">
                        {item.desc}
                      </p>
                    </div>
                  </div>
                ))}
              </div>
            </section>

            {/* 4. CHOOSE FROM THE CATALOG (COMPACT GRID TRIGGER) */}
            <section className="bg-white border-t border-b border-slate-200 py-16">
              <div className="max-w-7xl mx-auto px-4 md:px-8 flex flex-col lg:flex-row items-center gap-10">
                <div className="flex-1 space-y-5 text-left">
                  <span className="text-xs font-mono font-bold tracking-widest text-[#D4A017] uppercase block mb-1">75+ SPECIFICATION FILES AVAILABLE</span>
                  <h3 className="text-3xl font-extrabold tracking-tight text-slate-900 font-display leading-tight">
                    Custom Meshed Vegetable, Fruit, and Herbal Powders
                  </h3>
                  <p className="text-sm text-slate-650 leading-relaxed font-sans">
                    Browse our extensive catalog containing standard culinary garlic, red/white onion, vibrant beetroot, spray-dried fruit pulp essences (Alphonso mango, pink guava, citrus), and medicinal botanicals (pure neem, moringa, curry leaf).
                  </p>
                  
                  <div className="pt-2">
                    <button
                      onClick={() => { setActiveTab("products"); window.scrollTo({ top: 300, behavior: "smooth" }); }}
                      className="px-6 py-3.5 bg-[#1F6B3A] hover:bg-emerald-800 text-white hover:border-emerald-600 border border-emerald-950/20 text-xs font-bold font-display uppercase tracking-widest rounded-xl transition shadow-xs cursor-pointer inline-flex items-center gap-1.5"
                    >
                      Open Sourcing Database <ArrowRight className="w-4 h-4 text-[#D4A017]" />
                    </button>
                  </div>
                </div>

                <div className="flex-1 w-full grid grid-cols-2 gap-4">
                  <div className="p-5 bg-[#F7F9F8] border border-slate-200 rounded-2xl hover:border-emerald-500 transition">
                    <span className="text-[10px] font-mono font-bold text-[#D4A017]">VEGETABLE GRADES</span>
                    <h4 className="font-bold font-sans text-sm text-slate-800 mt-1">Carrot, Spinach & Tomato ABC</h4>
                    <p className="text-[11px] text-slate-400 mt-1.5">Available in A1, Rich, TPM & TPS specifications.</p>
                  </div>

                  <div className="p-5 bg-[#F7F9F8] border border-slate-200 rounded-2xl hover:border-emerald-500 transition">
                    <span className="text-[10px] font-mono font-bold text-[#1F6B3A]">FRUIT EXTRACTS</span>
                    <h4 className="font-bold font-sans text-sm text-slate-800 mt-1">Banana, Papaya & Lemon</h4>
                    <p className="text-[11px] text-slate-400 mt-1.5">Spray-dried pure juice crystals with optimal shelf stability.</p>
                  </div>

                  <div className="p-5 bg-[#F7F9F8] border border-slate-200 rounded-2xl hover:border-emerald-500 transition">
                    <span className="text-[10px] font-mono font-bold text-slate-500">HERBAL BOTANICALS</span>
                    <h4 className="font-bold font-sans text-sm text-slate-800 mt-1">Moringa, Neem & Mint</h4>
                    <p className="text-[11px] text-slate-400 mt-1.5">Uncompromised cellular bio-availability for premium brands.</p>
                  </div>

                  <div className="p-5 bg-[#F7F9F8] border border-slate-200 rounded-2xl hover:border-emerald-500 transition">
                    <span className="text-[10px] font-mono font-bold text-emerald-900">SOLUBLE BEVERAGES</span>
                    <h4 className="font-bold font-sans text-sm text-slate-800 mt-1">Black Tea & Chicory Coffee</h4>
                    <p className="text-[11px] text-slate-400 mt-1.5">Instant dry-mix dissolution in both hot and cold water matrices.</p>
                  </div>
                </div>
              </div>
            </section>

            {/* 5. USER TESTIMONIAL CAROUSEL PANEL */}
            <section className="max-w-7xl mx-auto px-4 md:px-8">
              <div className="bg-linear-to-b from-[#1F6B3A]/5 to-[#F7F9F8] border border-emerald-900/10 rounded-3xl p-8 md:p-12">
                <div className="text-center max-w-lg mx-auto mb-10">
                  <span className="text-xs font-mono font-bold tracking-widest text-[#D4A017] uppercase">CONFIRMED TRUST FILES</span>
                  <h3 className="text-2xl font-bold font-display text-slate-900 mt-1">International Procurement Feedback</h3>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                  {REVIEWS.map((rev) => (
                    <div key={rev.author} className="bg-white border border-slate-200 rounded-2xl p-6 flex flex-col justify-between shadow-2xs">
                      <p className="text-xs text-slate-650 leading-relaxed font-sans italic">
                        "{rev.quote}"
                      </p>
                      
                      <div className="mt-5 pt-4 border-t border-slate-100 flex items-center justify-between">
                        <div>
                          <p className="text-xs font-bold text-slate-900 font-sans">{rev.author}</p>
                          <p className="text-[10px] text-slate-400 font-sans">{rev.role}</p>
                        </div>
                        <span className="text-[10px] font-mono font-bold bg-[#1F6B3A]/10 text-[#1F6B3A] px-2 py-0.5 rounded-full uppercase">
                          {rev.country}
                        </span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </section>

          </div>
        )}

        {/* VIEW: PRODUCT CATALOG & INGREDIENTS */}
        {activeTab === "products" && (
          <ProductCatalog 
            rfqItems={rfqItems} 
            addRfqItem={addRfqItem} 
            removeRfqItem={removeRfqItem} 
          />
        )}

        {/* VIEW: SOURCING PROCESS & QUALITY CONTROL FLOW */}
        {activeTab === "process" && (
          <div className="py-12 max-w-7xl mx-auto px-4 md:px-8 space-y-16">
            
            {/* Introductory Header */}
            <div className="text-center max-w-3xl mx-auto">
              <span className="text-xs font-mono font-bold tracking-widest text-[#D4A017] uppercase block mb-1">HYGIENIC SAFETY STANDARDS</span>
              <h3 className="text-3xl font-extrabold tracking-tight text-slate-900 font-display">
                Seven-Step Quality Assurance Workflow
              </h3>
              <p className="text-sm font-sans text-slate-500 mt-2">
                We operate under strict commercial procedures to protect bulk cargo packages against humidity variance, microbial load, and heavy metal elements.
              </p>
            </div>

            {/* Visual Timeline Steps (Detailed representation) */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 items-stretch">
              {QA_STEPS.map((step, idx) => (
                <div key={step.phase} className="bg-white border border-slate-200 hover:border-[#1F6B3A] rounded-2xl p-6 flex flex-col justify-between transition-all group relative">
                  
                  {/* Subtle Connecting Lines for desktop */}
                  {idx < QA_STEPS.length - 1 && (
                    <div className="hidden lg:block absolute top-[25%] -right-3.5 w-7 border-t border-dashed border-slate-300 z-10" />
                  )}

                  <div className="space-y-4">
                    <span className="text-xs font-mono font-bold text-[#D4A017] tracking-widest block bg-[#F7F9F8] border border-slate-200 w-fit px-2.5 py-0.5 rounded-md">
                      PHASE {step.phase}
                    </span>
                    <h4 className="text-sm font-bold text-slate-900 font-sans group-hover:text-[#1F6B3A] transition">
                      {step.name}
                    </h4>
                    <p className="text-xs text-slate-500 leading-relaxed font-sans">
                      {step.desc}
                    </p>
                  </div>

                  <div className="pt-4 mt-4 border-t border-slate-100 flex items-center justify-between text-[11px] font-mono text-slate-400">
                    <span>STATUS: {idx === QA_STEPS.length - 1 ? "SHIPPED OUT" : "AUDITED PASS"}</span>
                    <CheckCircle className="w-4 h-4 text-emerald-600 shrink-0" />
                  </div>
                </div>
              ))}
            </div>

            {/* Merchant Export Services Bento layout */}
            <div className="bg-white border border-emerald-900/10 rounded-3xl p-8 md:p-12 shadow-xs grid grid-cols-1 lg:grid-cols-3 gap-8">
              <div className="space-y-4 text-left">
                <span className="text-xs font-mono font-bold tracking-widest text-[#D4A017] uppercase block">EXCLUSIVELY B2B</span>
                <h4 className="text-xl font-bold font-display text-slate-900">Comprehensive Sourcing Solutions</h4>
                <p className="text-xs text-slate-500 leading-relaxed font-sans">
                  KanhaiyaExim handles more than standard merchant operations. We construct personalized partnerships covering container consolidation, customizable sifting, and custom packaging.
                </p>
                <div className="space-y-2 pt-2 text-xs font-sans text-slate-600 font-semibold">
                  <div className="flex items-center gap-2"><Check className="w-4 h-4 text-emerald-600" /> Phytosanitary Clearance Guaranteed</div>
                  <div className="flex items-center gap-2"><Check className="w-4 h-4 text-emerald-600" /> SGS Laboratory Inspections Ready</div>
                  <div className="flex items-center gap-2"><Check className="w-4 h-4 text-emerald-600" /> Secure Ocean Container Drayage</div>
                </div>
              </div>

              <div className="lg:col-span-2 grid grid-cols-1 sm:grid-cols-2 gap-4 text-left">
                <div className="bg-[#F7F9F8] border border-slate-200 rounded-2xl p-5 space-y-2">
                  <span className="text-xs font-bold text-emerald-900 uppercase tracking-widest font-display">Merchant Exporting</span>
                  <p className="text-xs text-slate-505 leading-relaxed">Handling regulatory mandates, Customs clearing, Spices Board registration, and standard cargo Bill of Lading protocols.</p>
                </div>

                <div className="bg-[#F7F9F8] border border-slate-200 rounded-2xl p-5 space-y-2">
                  <span className="text-xs font-bold text-emerald-900 uppercase tracking-widest font-display">Bespoke Product Sourcing</span>
                  <p className="text-xs text-slate-505 leading-relaxed">Direct connection to Nashik agriculture farming hubs, ensuring raw material index stability and peak competitive pricing grids.</p>
                </div>

                <div className="bg-[#F7F9F8] border border-slate-200 rounded-2xl p-5 space-y-2">
                  <span className="text-xs font-bold text-emerald-900 uppercase tracking-widest font-display">Export Documentation Support</span>
                  <p className="text-xs text-slate-505 leading-relaxed">Fast creation of Certificate of Origin (COO), Phytosanitary health checks, custom SGS certifications, and correct HS tariff classifications.</p>
                </div>

                <div className="bg-[#F7F9F8] border border-slate-200 rounded-2xl p-5 space-y-2">
                  <span className="text-xs font-bold text-emerald-900 uppercase tracking-widest font-display">OEM & Private Label Services</span>
                  <p className="text-xs text-slate-505 leading-relaxed">Comprehensive customer branding of retail pouches (100g, 250g, 500g, 1kg), glass jars or fiber tins shipped export-ready.</p>
                </div>
              </div>
            </div>

          </div>
        )}

        {/* VIEW: LOGISTICS, PACKAGING & SIZES */}
        {activeTab === "packaging" && (
          <div className="py-12 max-w-7xl mx-auto px-4 md:px-8 space-y-16">
            
            {/* Introductory Header */}
            <div className="text-center max-w-3xl mx-auto">
              <span className="text-xs font-mono font-bold tracking-widest text-[#D4A017] uppercase block mb-1">PROTECTIVE LOGISTICS BARRIER</span>
              <h3 className="text-3xl font-extrabold tracking-tight text-slate-900 font-display">
                Packaging Systems Designed For Global Transit
              </h3>
              <p className="text-sm font-sans text-slate-550 mt-2">
                Protecting dehydrated vegetable & fruit powders against moisture, oxidation, and transit compression during long maritime voyages.
              </p>
            </div>

            {/* Choose Packaging weights cards block */}
            <div className="bg-white border border-slate-200 rounded-3xl p-6 md:p-8 space-y-6">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-100 pb-4 text-left">
                <div>
                  <h4 className="font-bold text-slate-900 font-sans text-sm tracking-wide uppercase">Available Container Packaging Metric Sizes</h4>
                  <p className="text-xs text-slate-500 font-sans mt-0.5 font-medium">Bespoke filling volumes as per buyer specification requests</p>
                </div>
                <span className="text-xs font-mono font-bold text-[#1F6B3A]">MOQ: 250 kg</span>
              </div>

              {/* Grid of weights */}
              <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-8 gap-3.5">
                {PACKAGING_SIZES.map((size) => (
                  <div key={size} className="bg-[#F7F9F8] border border-slate-200 rounded-xl py-5 px-4 text-center hover:border-emerald-500 transition group hover:bg-white shadow-2xs">
                    <span className="block font-display font-extrabold text-[#1F6B3A] text-lg group-hover:scale-110 transition duration-300">
                      {size}
                    </span>
                    <span className="block text-[10px] text-slate-450 font-mono mt-1 font-semibold uppercase">
                      {Number(size.replace("g", "").replace("kg", "")) < 5 ? "Retail Pouch" : "Cargo Bulk"}
                    </span>
                  </div>
                ))}
              </div>
            </div>

            {/* Packaging Types Grid layout */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 items-stretch text-left">
              {PACKAGING_TYPES.map((pkg) => (
                <div key={pkg.title} className="bg-white border border-slate-200 rounded-2xl p-6 hover:border-[#1F6B3A] transition duration-300 flex items-start gap-4 shadow-2xs">
                  <div className="w-10 h-10 rounded-xl bg-emerald-50 text-[#1F6B3A] flex items-center justify-center shrink-0 border border-emerald-950/5">
                    <Layers className="w-5 h-5 text-emerald-800" />
                  </div>
                  <div className="space-y-1.5 ">
                    <h4 className="font-bold font-sans text-slate-800 text-sm">{pkg.title}</h4>
                    <p className="text-xs text-slate-500 leading-relaxed">{pkg.desc}</p>
                  </div>
                </div>
              ))}
            </div>

            {/* Targeted Buyer profiles section */}
            <div className="bg-white border border-slate-200 rounded-3xl p-6 md:p-8 space-y-6 text-left">
              <div className="text-center max-w-xl mx-auto space-y-1">
                <span className="text-xs font-mono font-bold text-[#D4A017] uppercase tracking-widest">WHO WE SOURCE FOR</span>
                <h4 className="text-xl font-bold font-display text-slate-900">Global Ingredient Importer Demographics</h4>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {TARGET_BUYERS.map((cur) => (
                  <div key={cur.name} className="p-5 rounded-2xl border border-slate-200 hover:border-[#1F6B3A] bg-[#F7F9F8] transition space-y-2">
                    <span className="inline-flex px-2 py-0.5 bg-emerald-100/60 text-emerald-900 rounded-md text-[10px] font-mono font-bold uppercase">
                      Verified Client Profile
                    </span>
                    <h5 className="font-bold text-slate-800 font-sans text-sm">{cur.name}</h5>
                    <p className="text-xs text-slate-500 leading-relaxed">{cur.desc}</p>
                  </div>
                ))}
              </div>
            </div>
            
          </div>
        )}

        {/* VIEW: CONTACTS & DETAILED DIRECT TRADE REQUEST QUOTE */}
        {activeTab === "contact" && (
          <div className="py-12 max-w-7xl mx-auto px-4 md:px-8 space-y-16">
            
            {/* Interactive Nashik Maps Coordinates Frame */}
            <TeamAndMap />

            {/* Dynamic Sourcing Inquiry Request Form Container */}
            <div id="quote_form_section" className="scroll-mt-24">
              <div className="bg-white border border-emerald-900/10 rounded-3xl p-6 md:p-10 shadow-lg relative overflow-hidden">
                <div className="absolute top-0 right-0 w-80 h-80 bg-emerald-500/5 rounded-full blur-3xl pointer-events-none" />
                <div className="absolute bottom-0 left-0 w-80 h-80 bg-amber-500/5 rounded-full blur-3xl pointer-events-none" />

                {/* Submitting Success Dialogue Frame */}
                {submitSuccess ? (
                  <div className="py-12 text-center max-w-lg mx-auto space-y-6 animate-fade-in">
                    <div className="w-16 h-16 rounded-full bg-emerald-100 text-[#1F6B3A] border-4 border-white shadow-md mx-auto flex items-center justify-center">
                      <Check className="w-8 h-8 font-bold animate-pulse" />
                    </div>
                    
                    <div className="space-y-2">
                      <span className="text-[10px] bg-emerald-50 text-[#1F6B3A] font-mono font-bold tracking-widest px-2.5 py-1 rounded-md uppercase border border-emerald-500/20">
                        Inquiry Securely Issued
                      </span>
                      <h4 className="text-2xl font-bold font-display text-slate-900">Quotation Ticket Created</h4>
                      <p className="text-xs text-slate-500 leading-normal font-sans">
                        Thank you for drafting your sourcing parameters with KanhaiyaExim. Abhijeet Tidke and Pritesh Khode have received your container requirements.
                      </p>
                    </div>

                    <div className="bg-[#F7F9F8] border border-slate-200 rounded-2xl p-4.5 font-mono text-xs text-left space-y-2.5">
                      <div className="flex justify-between">
                        <span className="text-slate-400">Request Reference:</span>
                        <span className="font-bold text-[#D4A017]">{quoteReference}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-slate-400">Compliance Desk:</span>
                        <span className="font-bold text-slate-700">Nashik Main Office</span>
                      </div>
                      <div className="flex justify-between font-bold">
                        <span className="text-slate-400 font-medium">Follow-Up SLA Time:</span>
                        <span className="text-emerald-705">&lt; 4 business hours</span>
                      </div>
                    </div>

                    <p className="text-[11px] text-slate-400">
                      A summary confirmation receipt has been generated for your audit.
                    </p>

                    <button
                      id="reset_quote_success_btn"
                      onClick={resetFormState}
                      className="px-6 py-3 bg-[#1F6B3A] hover:bg-emerald-800 text-white hover:border-emerald-700 border border-emerald-950/20 text-xs font-bold uppercase font-display tracking-widest rounded-xl transition"
                    >
                      Draft Another Sourcing Cart
                    </button>
                  </div>
                ) : (
                  <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
                    
                    {/* Left Info bar inside form (4 Cols) */}
                    <div className="lg:col-span-4 space-y-6 text-left col-span-1">
                      <div>
                        <span className="text-xs font-mono font-bold text-[#D4A017] uppercase tracking-widest">SECURE RFQ ROUTER</span>
                        <h4 className="text-2xl font-bold text-slate-900 font-display mt-0.5">Request International Quotation</h4>
                        <p className="text-xs text-slate-500 leading-relaxed font-sans mt-2">
                          Your draft request will route directly to Abhijeet Tidke (Proprietor) and our ocean cargo coordinators. We support FOB, CFR, or CIF delivery protocols.
                        </p>
                      </div>

                      {/* Draft Cart Status inside the form block */}
                      <div className="p-4.5 bg-emerald-50/40 border border-emerald-900/10 rounded-2xl space-y-3.5 text-xs text-slate-650">
                        <h5 className="font-bold font-sans text-slate-800 flex items-center gap-1.5 uppercase tracking-wider text-[11px]">
                          <ShoppingCart className="w-4 h-4 text-[#1F6B3A]" /> Draft Sourcing Cart Checklist
                        </h5>
                        
                        {rfqItems.length === 0 ? (
                          <div className="text-slate-500 font-sans py-1 text-[11px] leading-relaxed">
                            No individual ingredients selected. Simply search the <span onClick={() => { setActiveTab("products"); window.scrollTo({ top: 300, behavior: "smooth" }); }} className="text-[#1F6B3A] font-bold underline cursor-pointer hover:text-emerald-850">Ingredients Portfolio</span> to add custom ingredients dynamically.
                          </div>
                        ) : (
                          <div className="space-y-2">
                            <p className="text-[11px] text-[#1F6B3A] font-semibold">
                              {rfqItems.length} Products currently linked to form:
                            </p>
                            <div className="max-h-36 overflow-y-auto space-y-1.5 pr-1 text-[11px] font-mono leading-normal bg-white p-2 border border-slate-200 rounded-xl">
                              {rfqItems.map((item) => (
                                <div key={item.product.id} className="flex justify-between items-center text-slate-705 bg-[#F7F9F8] p-1.5 rounded-md">
                                  <span>{item.product.name}</span>
                                  <span className="font-bold text-[#D4A017]">{item.quantityValue} {item.quantityUnit}</span>
                                </div>
                              ))}
                            </div>
                          </div>
                        )}
                      </div>

                      {/* Compliance list */}
                      <div className="space-y-2.5 font-sans text-xs text-slate-500">
                        <div className="flex items-center gap-2"><CheckCircle className="w-4 h-4 text-emerald-600 inline shrink-0" /> Fast sample shipment coordination</div>
                        <div className="flex items-center gap-2"><CheckCircle className="w-4 h-4 text-emerald-600 inline shrink-0" /> Full technical specification sheet (COA)</div>
                        <div className="flex items-center gap-2"><CheckCircle className="w-4 h-4 text-emerald-600 inline shrink-0" /> Verified global shipping tariffs lookup</div>
                      </div>
                    </div>

                    {/* True Interactive Form Block (8 Cols) */}
                    <form onSubmit={handleFormSubmission} className="lg:col-span-8 grid grid-cols-1 sm:grid-cols-2 gap-4 text-left col-span-1">
                      
                      <div>
                        <label className="block text-xs font-bold text-slate-700 font-sans mb-1.5 uppercase tracking-wide">
                          Your Name <span className="text-rose-500">*</span>
                        </label>
                        <div className="relative">
                          <input
                            id="form_input_name"
                            required
                            type="text"
                            placeholder="John Doe"
                            value={formName}
                            onChange={(e) => setFormName(e.target.value)}
                            className="w-full rounded-xl bg-[#F7F9F8] border border-slate-300 px-4 py-3 text-xs text-slate-900 placeholder-slate-400 focus:outline-hidden focus:ring-1 focus:ring-emerald-500 focus:border-emerald-500 shadow-2xs"
                          />
                        </div>
                      </div>

                      <div>
                        <label className="block text-xs font-bold text-slate-700 font-sans mb-1.5 uppercase tracking-wide">
                          Company Name <span className="text-rose-500">*</span>
                        </label>
                        <input
                          id="form_input_company"
                          required
                          type="text"
                          placeholder="International Food Brands Ltd."
                          value={formCompany}
                          onChange={(e) => setFormCompany(e.target.value)}
                          className="w-full rounded-xl bg-[#F7F9F8] border border-slate-300 px-4 py-3 text-xs text-slate-900 placeholder-slate-400 focus:outline-hidden focus:ring-1 focus:ring-emerald-500 focus:border-emerald-500 shadow-2xs"
                        />
                      </div>

                      <div>
                        <label className="block text-xs font-bold text-slate-700 font-sans mb-1.5 uppercase tracking-wide">
                          Target Destination Port
                        </label>
                        <input
                          id="form_input_port"
                          type="text"
                          placeholder="e.g., Hamburg Port, Germany / London Gateway"
                          value={formDestinationPort}
                          onChange={(e) => setFormDestinationPort(e.target.value)}
                          className="w-full rounded-xl bg-[#F7F9F8] border border-slate-300 px-4 py-3 text-xs text-slate-900 placeholder-slate-400 focus:outline-hidden focus:ring-1 focus:ring-emerald-500 focus:border-emerald-500 shadow-2xs"
                        />
                      </div>

                      <div>
                        <label className="block text-xs font-bold text-slate-700 font-sans mb-1.5 uppercase tracking-wide">
                          Country <span className="text-rose-500">*</span>
                        </label>
                        <input
                          id="form_input_country"
                          required
                          type="text"
                          placeholder="e.g., Germany / United Kingdom / USA"
                          value={formCountry}
                          onChange={(e) => setFormCountry(e.target.value)}
                          className="w-full rounded-xl bg-[#F7F9F8] border border-slate-300 px-4 py-3 text-xs text-slate-900 placeholder-slate-400 focus:outline-hidden focus:ring-1 focus:ring-emerald-500 focus:border-emerald-500 shadow-2xs"
                        />
                      </div>

                      <div>
                        <label className="block text-xs font-bold text-slate-700 font-sans mb-1.5 uppercase tracking-wide">
                          Email Address <span className="text-rose-500">*</span>
                        </label>
                        <input
                          id="form_input_email"
                          required
                          type="email"
                          placeholder="procurement@foodbrand.com"
                          value={formEmail}
                          onChange={(e) => setFormEmail(e.target.value)}
                          className="w-full rounded-xl bg-[#F7F9F8] border border-slate-300 px-4 py-3 text-xs text-slate-900 placeholder-slate-400 focus:outline-hidden focus:ring-1 focus:ring-emerald-500 focus:border-emerald-500 shadow-2xs"
                        />
                      </div>

                      <div>
                        <label className="block text-xs font-bold text-slate-700 font-sans mb-1.5 uppercase tracking-wide">
                          Phone / WhatsApp Number
                        </label>
                        <input
                          id="form_input_phone"
                          type="tel"
                          placeholder="+1 (555) 123-4567"
                          value={formPhone}
                          onChange={(e) => setFormPhone(e.target.value)}
                          className="w-full rounded-xl bg-[#F7F9F8] border border-slate-300 px-4 py-3 text-xs text-slate-900 placeholder-slate-400 focus:outline-hidden focus:ring-1 focus:ring-emerald-500 focus:border-emerald-500 shadow-2xs"
                        />
                      </div>

                      <div className="sm:col-span-2">
                        <label className="block text-xs font-bold text-slate-700 font-sans mb-1.5 uppercase tracking-wide">
                          Product ID & Target Quantities List
                        </label>
                        <textarea
                          id="form_input_sourcing_list"
                          rows={4}
                          placeholder={rfqItems.length > 0 ? "" : "e.g., • Moringa Leaf Powder (500 kg), • Tomato Premium (1 Ton)"}
                          value={sourcingListText}
                          onChange={(e) => setSourcingListText(e.target.value)}
                          className="w-full rounded-xl bg-[#F7F9F8] border border-slate-300 px-4 py-3.5 text-xs text-slate-900 placeholder-slate-400 font-mono focus:outline-hidden focus:ring-1 focus:ring-emerald-500 focus:border-emerald-500 shadow-2xs"
                        />
                      </div>

                      <div className="sm:col-span-2">
                        <label className="block text-xs font-bold text-slate-700 font-sans mb-1.5 uppercase tracking-wide">
                          Packaging & Container Sizing Requirements
                        </label>
                        <input
                          id="form_input_pkg_text"
                          type="text"
                          placeholder="e.g., HDPE Drums, multi-layer Kraft bags or private-label pouches requested..."
                          value={packageRequirementsText}
                          onChange={(e) => setPackageRequirementsText(e.target.value)}
                          className="w-full rounded-xl bg-[#F7F9F8] border border-slate-300 px-4 py-3 text-xs text-slate-900 placeholder-slate-400 focus:outline-hidden focus:ring-1 focus:ring-emerald-500 focus:border-emerald-500 shadow-2xs"
                        />
                      </div>

                      <div className="sm:col-span-2">
                        <label className="block text-xs font-bold text-slate-700 font-sans mb-1.5 uppercase tracking-wide">
                          Additional Messages or Customized Formulations Spec Notes
                        </label>
                        <textarea
                          id="form_input_message"
                          rows={3}
                          placeholder="Detail your requested mesh sizes, technical certifications, or private label artwork parameters here..."
                          value={formCustomMessage}
                          onChange={(e) => setFormCustomMessage(e.target.value)}
                          className="w-full rounded-xl bg-[#F7F9F8] border border-slate-300 px-4 py-3 text-xs text-slate-900 placeholder-slate-400 focus:outline-hidden focus:ring-1 focus:ring-emerald-500 focus:border-emerald-500 shadow-2xs"
                        />
                      </div>

                      <div className="sm:col-span-2 pt-2">
                        <button
                          id="submit_rfq_quote_form_btn"
                          type="submit"
                          disabled={isSubmitting}
                          className="w-full py-4 bg-[#1F6B3A] hover:bg-emerald-805 text-white rounded-xl text-xs font-bold font-display uppercase tracking-wider flex items-center justify-center gap-2 shadow-sm transition disabled:opacity-50 cursor-pointer border-b border-emerald-950/20"
                        >
                          {isSubmitting ? (
                            <>
                              <svg className="animate-spin h-5 w-5 text-white" fill="none" viewBox="0 0 24 24">
                                <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" />
                                <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 4.418 3.582 8 8 8v-4c-2.022 0-3.882-.777-5.291-2.091z" />
                              </svg>
                              FORM PROCESSING...
                            </>
                          ) : (
                            <>
                              <Ship className="w-4 h-4 text-[#D39E18]" /> REQUEST QUOTATION
                            </>
                          )}
                        </button>
                      </div>

                    </form>
                  </div>
                )}

              </div>
            </div>

            {/* 6. FAQ DETAILS PANEL */}
            <section className="bg-[#F7F9F8] border border-slate-205 rounded-3xl p-6 md:p-10 text-left">
              <div className="mb-8 flex items-center gap-2 border-b border-slate-200 pb-4">
                <HelpCircle className="w-6 h-6 text-[#1F6B3A] shrink-0" />
                <div>
                  <h4 className="text-xl font-bold font-display text-slate-900">Commercial Sourcing FAQ</h4>
                  <p className="text-xs text-slate-505 font-sans mt-0.5">International buyers guidelines for KanhaiyaExim exports</p>
                </div>
              </div>

              <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
                {FAQS.map((faq, idx) => (
                  <div key={idx} className="bg-white border border-slate-200 rounded-2xl p-5 hover:border-[#1F6B3A] transition">
                    <h5 className="font-bold text-slate-800 font-sans text-sm flex items-start gap-2">
                      <span className="text-[#D4A017] shrink-0">Q.</span> {faq.q}
                    </h5>
                    <p className="text-xs text-slate-500 leading-relaxed font-sans mt-2.5 pl-6 border-l-2 border-emerald-50">
                      {faq.a}
                    </p>
                  </div>
                ))}
              </div>
            </section>

          </div>
        )}

      </main>

      {/* Corporate Base Footer Area */}
      <Footer 
        onSelectTab={setActiveTab}
        openPrivacyModal={() => setIsPrivacyOpen(true)}
        openTermsModal={() => setIsTermsOpen(true)}
      />

      {/* Compliance Modals */}
      <PrivacyPolicyModal isOpen={isPrivacyOpen} onClose={() => setIsPrivacyOpen(false)} />
      <TermsConditionsModal isOpen={isTermsOpen} onClose={() => setIsTermsOpen(false)} />

    </div>
  );
}
