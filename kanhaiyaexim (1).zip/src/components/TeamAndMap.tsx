/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from "react";
import { Phone, Mail, Navigation2, MapPin, ExternalLink, Compass, ShieldCheck, HelpCircle, Activity } from "lucide-react";

interface TeamMember {
  name: string;
  role: string;
  phone: string;
  email: string;
  desc: string;
}

const TEAM: TeamMember[] = [
  {
    name: "Abhijeet Tidke",
    role: "Founder & Proprietor",
    phone: "9699265156",
    email: "kanhaiyaexim@yahoo.com",
    desc: "Oversees KanhaiyaExim's global strategic alliances, client partnerships, and direct manufacturer audit cycles."
  },
  {
    name: "Pritesh Khode",
    role: "Export Sales Manager",
    phone: "9322548985",
    email: "kanhaiyaexim@yahoo.com",
    desc: "Coordinates direct relations with international buyers, custom clearances, ocean billings, and freight forwarding audits."
  },
  {
    name: "Ansh Tidke",
    role: "Operations & Procurement Manager",
    phone: "9226816373",
    email: "kanhaiyaexim@yahoo.com",
    desc: "Manages direct supply verification metrics, packaging standards audits, and farm-to-warehouse logistics workflows."
  }
];

export default function TeamAndMap() {
  const [activeCard, setActiveCard] = useState<number>(0);
  const [mapZoom, setMapZoom] = useState(13);

  // Address and coordinate values from user spec
  const latitude = "20.1053";
  const longitude = "73.8871";
  const addressString = "Janori, Nashik, Maharashtra – 422206, India";
  
  // Custom Google Maps Links
  const googleMapsUrl = `https://www.google.com/maps/place/20%07'19.1%22N+73%07'53.1%22E/@20.1053,73.8871,15z/`;
  const getDirectionsUrl = `https://www.google.com/maps/dir/?api=1&destination=${latitude},${longitude}`;

  const formatWhatsAppLink = (phone: string, name: string) => {
    const text = encodeURIComponent(`Hello ${name},\nI am writing from the KanhaiyaExim B2B portal regarding global sourcing of dehydrated powders.`);
    return `https://wa.me/91${phone}?text=${text}`;
  };

  return (
    <section className="py-12 bg-white">
      <div className="max-w-7xl mx-auto px-4 md:px-8">
        
        {/* Section Headline */}
        <div className="text-center max-w-3xl mx-auto mb-12">
          <span className="text-xs font-mono font-bold tracking-widest text-[#D4A017] uppercase block mb-1">GLOBAL COMMUNICATION LAYER</span>
          <h3 className="text-3xl font-extrabold tracking-tight text-slate-900 font-display">
            Direct Trade Desk & Physical Headquarters
          </h3>
          <p className="text-sm font-sans text-slate-500 mt-2">
            Connect directly with our corporate officers. We maintain clear and direct B2B customer support on WhatsApp and direct telephone wire lines.
          </p>
        </div>

        {/* Column Grid: Team Contacts on Left, Real Coordinates and Maps Visual on Right */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          
          {/* Team Contact Cards (Left - 5 Cols) */}
          <div className="lg:col-span-5 space-y-4">
            <h4 className="text-xs font-mono font-bold uppercase tracking-wider text-[#1F6B3A] border-b border-slate-100 pb-2 flex items-center gap-1.5 mb-2">
              <Compass className="w-4 h-4 text-[#D4A017]" /> Trade Account Managers
            </h4>

            {TEAM.map((member, idx) => (
              <div
                key={member.name}
                id={`team_card_${idx}`}
                className={`border rounded-2xl p-5 transition-all duration-300 relative overflow-hidden ${
                  activeCard === idx
                    ? "border-[#1F6B3A] bg-emerald-50/20 shadow-xs ring-1 ring-[#1F6B3A]/10"
                    : "border-slate-200 bg-white hover:border-slate-300 hover:shadow-xs"
                }`}
                onClick={() => setActiveCard(idx)}
              >
                {/* Active Indicator Accent */}
                <div className={`absolute left-0 top-0 bottom-0 w-1 transition-all ${
                  activeCard === idx ? "bg-[#1F6B3A]" : "bg-transparent"
                }`} />

                <div className="flex justify-between items-start mb-2">
                  <div>
                    <h5 className="text-base font-bold text-slate-900 font-sans">{member.name}</h5>
                    <p className="text-xs text-[#1F6B3A] font-mono font-bold uppercase mt-0.5">{member.role}</p>
                  </div>
                  <span className="text-[10px] bg-slate-100 text-slate-500 font-mono px-2 py-0.5 rounded-md">
                    Nashik Desk
                  </span>
                </div>

                <p className="text-xs text-slate-500 leading-relaxed font-sans mb-4">
                  {member.desc}
                </p>

                {/* Interactive Communication Panel */}
                <div className="grid grid-cols-2 gap-2.5 pt-3 border-t border-slate-100">
                  {/* Telephone Trigger */}
                  <a
                    id={`team_call_${idx}`}
                    href={`tel:+91${member.phone}`}
                    className="flex items-center justify-center gap-1.5 px-3 py-2 border border-emerald-900/10 hover:border-[#1F6B3A] hover:bg-emerald-50/50 text-[11px] font-sans font-semibold text-slate-700 rounded-xl transition"
                  >
                    <Phone className="w-3.5 h-3.5 text-[#1F6B3A]" /> Call Direct
                  </a>

                  {/* WhatsApp Trigger */}
                  <a
                    id={`team_wa_${idx}`}
                    href={formatWhatsAppLink(member.phone, member.name)}
                    target="_blank"
                    rel="noreferrer"
                    className="flex items-center justify-center gap-1.5 px-3 py-2 bg-[#1F6B3A] text-white hover:bg-emerald-800 text-[11px] font-sans font-semibold rounded-xl shadow-xs transition"
                  >
                    <svg className="w-3.5 h-3.5 fill-current text-white shrink-0" viewBox="0 0 24 24">
                      <path d="M.057 24l1.687-6.163c-1.041-1.804-1.588-3.849-1.587-5.946C.06 5.348 5.397.01 12.008.01c3.202.001 6.212 1.246 8.477 3.513 2.266 2.268 3.507 5.28 3.505 8.484-.004 6.657-5.34 11.997-11.953 11.997-2.005-.001-3.973-.502-5.717-1.458L0 24zm6.59-4.846c1.6.95 3.188 1.449 4.825 1.451 5.436 0 9.859-4.42 9.863-9.864.002-2.637-1.023-5.115-2.883-6.978C16.57 1.899 14.1 1.025 11.47 1.025c-5.439 0-9.859 4.418-9.863 9.862 0 1.962.52 3.885 1.508 5.617L2.122 21.84l5.525-1.451h.001z"/>
                    </svg>
                    WhatsApp Chat
                  </a>
                </div>
              </div>
            ))}

            {/* Quick General Inquiry Email Block */}
            <div className="bg-[#F7F9F8] border border-emerald-950/5 rounded-2xl p-4 flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 bg-[#1F6B3A]/10 text-[#1F6B3A] rounded-xl flex items-center justify-center shrink-0">
                  <Mail className="w-5 h-5 text-emerald-800" />
                </div>
                <div>
                  <p className="text-xs font-bold text-slate-800">Corporate Email Sourcing</p>
                  <p className="text-[11px] text-slate-500 font-mono mt-0.5">kanhaiyaexim@yahoo.com</p>
                </div>
              </div>
              <a
                id="corporate_email_btn"
                href="mailto:kanhaiyaexim@yahoo.com?subject=B2B%20Sourcing%20Inquiry%20-%20KanhaiyaExim"
                className="p-2 cursor-pointer bg-white border border-slate-200 hover:border-[#1F6B3A] rounded-xl hover:text-[#1F6B3A] text-slate-500 transition shadow-xs"
                title="Write global sales desk email"
              >
                <ExternalLink className="w-4 h-4" />
              </a>
            </div>
          </div>

          {/* Interactive Geographical coordinates sheet (Right - 7 Cols) */}
          <div className="lg:col-span-7 bg-[#F7F9F8] border border-emerald-900/10 rounded-3xl p-6 md:p-8 space-y-6">
            
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-200 pb-4">
              <div>
                <span className="text-[10px] font-mono font-bold uppercase tracking-wider text-emerald-900">GEOLOCATION METRICS</span>
                <h4 className="text-xl font-bold font-display text-slate-900">Western Indian Agricultural Hub</h4>
              </div>
              
              <div className="flex items-center gap-2 text-xs bg-white border border-slate-200 rounded-xl px-3 py-1.5 font-mono text-slate-600">
                <Compass className="w-4 h-4 text-[#D4A017] animate-spin" />
                <span>NASHIK, MH, IND</span>
              </div>
            </div>

            {/* Simulated Live Vector Radar Map (Luxury Aesthetic) */}
            <div className="w-full h-64 bg-[#142A1C] border border-emerald-900/20 rounded-2xl relative overflow-hidden flex flex-col justify-between p-4 shadow-inner">
              
              {/* Radar Sweeper grid */}
              <div className="absolute inset-0 bg-[linear-gradient(rgba(31,107,58,0.15)_1px,transparent_1px),linear-gradient(90deg,rgba(31,107,58,0.15)_1px,transparent_1px)] bg-[size:24px_24px] pointer-events-none" />
              
              {/* Rotating Compass background lines */}
              <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-48 h-48 border border-emerald-500/10 rounded-full animate-pulse pointer-events-none" />
              <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-32 h-32 border border-emerald-500/20 rounded-full pointer-events-none" />

              {/* Coordinates center spot */}
              <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 z-10 flex flex-col items-center">
                <span className="w-4 h-4 rounded-full bg-[#D4A017] border-4 border-[#142A1C] ring-4 ring-[#D4A017]/30 animate-bounce" />
                <span className="text-[10px] font-mono font-bold text-white bg-[#1F6B3A] border border-emerald-500 px-2 py-0.5 rounded-md mt-1.5 shadow-md">
                  KanhaiyaExim HQ
                </span>
              </div>

              {/* Top Row Data */}
              <div className="z-10 flex justify-between items-start">
                <div className="font-mono text-[10px] text-emerald-400">
                  <div>LATITUDE: {latitude}° N</div>
                  <div>LONGITUDE: {longitude}° E</div>
                </div>
                <div className="font-mono text-[9px] text-slate-400 text-right uppercase bg-black/30 backdrop-blur-xs px-2 py-1 rounded-md border border-emerald-500/10">
                  <div>Status: GPS Lock</div>
                  <div>Accuracy: High-Precision</div>
                </div>
              </div>

              {/* Bottom Row Area Info */}
              <div className="z-10 bg-black/40 backdrop-blur-xs rounded-xl p-3 border border-emerald-500/20">
                <p className="text-xs font-semibold text-emerald-300 font-sans flex items-center gap-1.5">
                  <MapPin className="w-4 h-4 text-[#D4A017]" /> Janori, Nashik Agro District
                </p>
                <p className="text-[10.5px] text-slate-400 leading-normal font-sans mt-1">
                  Located near major agricultural growers and production farms, reducing transport times and securing cold-chain freshness.
                </p>
              </div>
            </div>

            {/* Geographical Stats Grid */}
            <div className="grid grid-cols-2 md:grid-cols-3 gap-4 font-sans text-xs">
              <div className="bg-white border border-slate-200/60 rounded-xl p-3.5 shadow-2xs">
                <p className="text-slate-400 font-medium">District Class</p>
                <p className="text-slate-800 font-bold mt-1 text-sm">Industrial Sourcing Center</p>
              </div>

              <div className="bg-white border border-slate-200/60 rounded-xl p-3.5 shadow-2xs">
                <p className="text-slate-400 font-medium">Logistics Reach</p>
                <p className="text-slate-800 font-bold mt-1 text-sm">Mumbai JNPT Port Connection</p>
              </div>

              <div className="col-span-2 md:col-span-1 bg-white border border-slate-200/60 rounded-xl p-3.5 shadow-2xs">
                <p className="text-slate-400 font-medium">Compliance status</p>
                <p className="text-emerald-700 font-bold mt-1 text-sm flex items-center gap-1">
                  <ShieldCheck className="w-4 h-4 text-emerald-600 inline" /> Trade Licensed
                </p>
              </div>
            </div>

            {/* Navigation and Directions Buttons */}
            <div className="pt-4 border-t border-slate-200 flex flex-col sm:flex-row gap-3">
              <a
                id="it_open_gmaps"
                href={googleMapsUrl}
                target="_blank"
                rel="noreferrer"
                className="flex-1 py-3 px-4 bg-white hover:bg-slate-50 border border-slate-300 rounded-xl text-xs font-bold font-display uppercase tracking-wider text-slate-700 hover:text-[#1F6B3A] hover:border-[#1F6B3A] transition shadow-2xs text-center flex items-center justify-center gap-1.5"
              >
                <Navigation2 className="w-4 h-4 text-[#1F6B3A]" /> Open in Google Maps
              </a>

              <a
                id="it_get_directions"
                href={getDirectionsUrl}
                target="_blank"
                rel="noreferrer"
                className="flex-1 py-3 px-4 bg-[#1F6B3A] hover:bg-emerald-800 text-white rounded-xl text-xs font-bold font-display uppercase tracking-wider transition shadow-2xs text-center flex items-center justify-center gap-1.5 border-b border-emerald-950/20"
              >
                <Compass className="w-4 h-4 text-[#D4A017]" /> Get Directions / Routing
              </a>
            </div>

          </div>

        </div>

      </div>
    </section>
  );
}
