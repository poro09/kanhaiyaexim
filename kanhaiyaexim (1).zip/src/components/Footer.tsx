/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from "react";
import { Mail, Globe, MapPin, Compass, ShieldAlert, Award, ArrowUp } from "lucide-react";

interface FooterProps {
  onSelectTab: (tab: string) => void;
  openPrivacyModal: () => void;
  openTermsModal: () => void;
}

export default function Footer({ onSelectTab, openPrivacyModal, openTermsModal }: FooterProps) {
  const handleScrollToTop = () => {
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  return (
    <footer className="bg-[#111827] text-slate-350 border-t border-[#1F6B3A]/30 pt-16 pb-8 font-sans">
      <div className="max-w-7xl mx-auto px-4 md:px-8">
        
        {/* Main Content Info Rows */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-12 gap-10 border-b border-slate-800 pb-12">
          
          {/* Brand and Description (Col 4) */}
          <div className="lg:col-span-5 space-y-4">
            <div className="flex items-center gap-1">
              <span className="font-display font-black text-2xl tracking-tight text-white">
                Kanhaiya<span className="text-[#1F6B3A]">Exim</span>
              </span>
              <span className="w-1.5 h-1.5 rounded-full bg-[#D4A017]" />
            </div>
            <p className="text-sm text-slate-400 leading-relaxed max-w-sm">
              We are premium merchant exporters of dehydrated vegetable, fruit, herbal, and specialty powders. Connecting international procurement managers directly to robust Indian agricultural sourcing solutions.
            </p>
            
            {/* Certifications Row */}
            <div className="flex flex-wrap gap-2 pt-2">
              <span className="inline-flex items-center gap-1 text-[10px] font-mono font-bold tracking-wider text-[#D4A017] bg-white/5 border border-[#D4A017]/25 px-2.5 py-1 rounded-md uppercase">
                <Award className="w-3.5 h-3.5" /> IEC Registered
              </span>
              <span className="inline-flex items-center gap-1 text-[10px] font-mono font-bold tracking-wider text-[#1F6B3A] bg-white/5 border border-[#1F6B3A]/30 px-2.5 py-1 rounded-md uppercase">
                GST Registered
              </span>
              <span className="inline-flex items-center gap-1 text-[10px] font-mono font-bold tracking-wider text-slate-300 bg-white/5 border border-slate-700 px-2.5 py-1 rounded-md uppercase">
                Merchant Exporter
              </span>
            </div>
          </div>

          {/* Sourcing Navigation (Col 3) */}
          <div className="lg:col-span-3 space-y-4">
            <h5 className="text-xs font-mono font-bold uppercase tracking-wider text-white">B2B Core Portfolios</h5>
            <ul className="space-y-2.5 text-xs">
              <li>
                <button 
                  onClick={() => { onSelectTab("products"); handleScrollToTop(); }}
                  className="hover:text-[#D4A017] transition text-slate-400 text-left"
                >
                  Vegetable & Leaf Powders
                </button>
              </li>
              <li>
                <button 
                  onClick={() => { onSelectTab("products"); handleScrollToTop(); }}
                  className="hover:text-[#D4A017] transition text-slate-400 text-left"
                >
                  Natural Fruit Powders
                </button>
              </li>
              <li>
                <button 
                  onClick={() => { onSelectTab("products"); handleScrollToTop(); }}
                  className="hover:text-[#D4A017] transition text-slate-400 text-left"
                >
                  Tea & Coffee Blends
                </button>
              </li>
              <li>
                <button 
                  onClick={() => { onSelectTab("packaging"); handleScrollToTop(); }}
                  className="hover:text-[#D4A017] transition text-slate-400 text-left"
                >
                  Packaging & Customized Blends
                </button>
              </li>
            </ul>
          </div>

          {/* Quick Trade Links (Col 2) */}
          <div className="lg:col-span-2 space-y-4">
            <h5 className="text-xs font-mono font-bold uppercase tracking-wider text-white">Company Actions</h5>
            <ul className="space-y-2.5 text-xs">
              <li>
                <button 
                  onClick={() => { onSelectTab("process"); handleScrollToTop(); }}
                  className="hover:text-[#D4A017] transition text-slate-400 text-left"
                >
                  Quality Assurance Workflow
                </button>
              </li>
              <li>
                <button 
                  onClick={() => { onSelectTab("contact"); handleScrollToTop(); }}
                  className="hover:text-[#D4A017] transition text-slate-400 text-left"
                >
                  Official Trade Office
                </button>
              </li>
              <li>
                <button 
                  onClick={() => { onSelectTab("products"); handleScrollToTop(); }}
                  className="hover:text-[#D4A017] transition text-slate-400 text-[#1F6B3A] font-bold text-left"
                >
                  Request Bulk Samples
                </button>
              </li>
              <li>
                <button 
                  onClick={openPrivacyModal}
                  className="hover:text-[#D4A017] transition text-slate-400 text-left"
                >
                  Privacy Policy Clause
                </button>
              </li>
              <li>
                <button 
                  onClick={openTermsModal}
                  className="hover:text-[#D4A017] transition text-slate-400 text-left"
                >
                  Trade Terms & Conditions
                </button>
              </li>
            </ul>
          </div>

          {/* Trade Desks Detail (Col 2) */}
          <div className="lg:col-span-2 space-y-4">
            <h5 className="text-xs font-mono font-bold uppercase tracking-wider text-white">Registration Grid</h5>
            <div className="space-y-3.5 text-xs text-slate-400 font-mono">
              <div className="space-y-0.5">
                <span className="block text-[10px] text-slate-500 uppercase">Export License (IEC)</span>
                <span className="block font-bold text-[#D4A017]">DAVPT2930Q</span>
              </div>
              <div className="space-y-0.5">
                <span className="block text-[10px] text-slate-500 uppercase">GSTIN Register ID</span>
                <span className="block font-bold text-white text-[11px]">27DAVPT2930Q1ZK</span>
              </div>
              <div className="space-y-0.5">
                <span className="block text-[10px] text-slate-500 uppercase">HQ Coordinate Hub</span>
                <span className="block text-white text-[11px]">20.1053° N, 73.8871° E</span>
              </div>
            </div>
          </div>

        </div>

        {/* Local Logistics & Contacts Panel */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 pt-8 pb-4 text-xs font-mono text-slate-400 border-b border-slate-800">
          <div className="flex items-center gap-2">
            <MapPin className="w-4 h-4 text-[#1F6B3A] shrink-0" />
            <span>Janori, Nashik, Maharashtra – 422206, India</span>
          </div>

          <div className="flex items-center gap-2">
            <Mail className="w-4 h-4 text-[#D4A017] shrink-0" />
            <a href="mailto:kanhaiyaexim@yahoo.com" className="hover:text-white transition">kanhaiyaexim@yahoo.com</a>
          </div>

          <div className="flex items-center gap-2 md:justify-end">
            <span className="text-[10px] text-[#1F6B3A] font-bold">● ONLINE ENQUIRY CHANNEL OPEN</span>
          </div>
        </div>

        {/* Footer Sub-base: Copyright and Top-Scroll */}
        <div className="pt-8 flex flex-col sm:flex-row justify-between items-center gap-4 text-slate-500 text-xs">
          <div>
            <span>© 2026 KanhaiyaExim. All Rights Reserved. Sourced & Processed in Nashik, Maharashtra, India.</span>
          </div>
          
          <button
            onClick={handleScrollToTop}
            className="flex items-center gap-1 px-3.5 py-1.5 border border-slate-800 hover:border-[#1F6B3A] hover:bg-slate-800 text-[10px] font-mono tracking-wider font-semibold uppercase text-slate-300 rounded-full transition cursor-pointer"
            title="Scroll to Top"
          >
            <ArrowUp className="w-3.5 h-3.5 text-[#D4A017]" /> TOP OF PAGE
          </button>
        </div>

      </div>
    </footer>
  );
}
