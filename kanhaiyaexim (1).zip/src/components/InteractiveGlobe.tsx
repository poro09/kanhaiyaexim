/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useRef, useEffect, useState } from "react";
import { Ship, Plane, Globe2, Compass, AlertCircle, Anchor } from "lucide-react";
import { MARKETS_WE_SERVE } from "../data";

interface Hub {
  id: string;
  name: string;
  lat: number;
  lng: number;
  label: string;
  distance?: string;
  transitAir?: string;
  transitSea?: string;
  port?: string;
}

const GLOBAL_HUBS: Hub[] = [
  { id: "germany", name: "Germany", lat: 51.1657, lng: 10.4515, label: "Frankfurt Hub (EU Distribution)", transitAir: "2-3 Days", transitSea: "22-26 Days", port: "Hamburg / Bremerhaven" },
  { id: "uk", name: "United Kingdom", lat: 55.3781, lng: -3.4360, label: "London Gateway (Trade Specialist)", transitAir: "2-3 Days", transitSea: "20-24 Days", port: "Port of Felixstowe / London" },
  { id: "usa", name: "United States", lat: 37.0902, lng: -95.7129, label: "New York/LA Ports (High Volume Bulk)", transitAir: "3-4 Days", transitSea: "28-35 Days", port: "New York / Los Angeles" },
  { id: "canada", name: "Canada", lat: 56.1304, lng: -106.3468, label: "Toronto/Vancouver (Nutraceuticals)", transitAir: "3-5 Days", transitSea: "32-38 Days", port: "Port of Vancouver / Montreal" },
  { id: "australia", name: "Australia", lat: -25.2744, lng: 133.7751, label: "Sydney Harbour (Superfoods Focus)", transitAir: "3-4 Days", transitSea: "18-22 Days", port: "Sydney / Melbourne" },
  { id: "uae", name: "UAE / Middle East", lat: 23.4241, lng: 53.8478, label: "Jebel Ali Port (Re-Export Center)", transitAir: "1-2 Days", transitSea: "6-8 Days", port: "Jebel Ali, Dubai" },
  { id: "europe", name: "Continental Europe", lat: 46.2276, lng: 2.2137, label: "Rotterdam Ingress (Ingredient Wholesale)", transitAir: "2-3 Days", transitSea: "21-25 Days", port: "Port of Rotterdam" }
];

// India Coordinates (Nashik Core)
const INDIA_COORDS = { id: "india", lat: 20.1053, lng: 73.8871, name: "KanhaiyaExim HQ", location: "Nashik, India" };

export default function InteractiveGlobe() {
  const containerRef = useRef<HTMLDivElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [selectedHub, setSelectedHub] = useState<Hub>(GLOBAL_HUBS[0]);
  const [dimensions, setDimensions] = useState({ width: 500, height: 500 });
  const [spin, setSpin] = useState(true);
  const rotationAngleRef = useRef(0);
  const mouseRef = useRef({ x: 0, y: 0, isDown: false, lastX: 0 });

  // Generate particle coordinate offsets to resemble natural earth continents
  const particlesRef = useRef<{ x: number; y: number; z: number; size: number; alpha: number }[]>([]);

  useEffect(() => {
    // Generate static point cloud for continents on a sphere of radius 150
    const points: { x: number; y: number; z: number; size: number; alpha: number }[] = [];
    const radius = 150;
    
    // Create random particles styled heavily dense in specific latitude/longitude grids representing continents.
    // This gives a beautiful matrix/3D hologram style earth continent distribution!
    const continentGrids = [
      // North America grid
      { latMin: 20, latMax: 65, lngMin: -125, lngMax: -70, weight: 0.8 },
      // South America grid
      { latMin: -45, latMax: 10, lngMin: -75, lngMax: -40, weight: 0.6 },
      // Eurasia grid
      { latMin: 35, latMax: 70, lngMin: -10, lngMax: 130, weight: 0.85 },
      // India & South Asia
      { latMin: 5, latMax: 30, lngMin: 65, lngMax: 100, weight: 0.95 },
      // Africa grid
      { latMin: -30, latMax: 30, lngMin: -15, lngMax: 45, weight: 0.65 },
      // Australia grid
      { latMin: -40, latMax: -12, lngMin: 112, lngMax: 153, weight: 0.7 }
    ];

    // Add some uniform background dust
    for (let i = 0; i < 250; i++) {
      const phi = Math.acos(Math.random() * 2 - 1);
      const theta = Math.random() * Math.PI * 2;
      points.push({
        x: radius * Math.sin(phi) * Math.cos(theta),
        y: radius * Math.cos(phi),
        z: radius * Math.sin(phi) * Math.sin(theta),
        size: Math.random() * 1.5 + 0.5,
        alpha: Math.random() * 0.3 + 0.1
      });
    }

    // Populate dense continental particles
    continentGrids.forEach(grid => {
      const density = Math.round(90 * grid.weight);
      for (let i = 0; i < density; i++) {
        const latDeg = grid.latMin + Math.random() * (grid.latMax - grid.latMin);
        const lngDeg = grid.lngMin + Math.random() * (grid.lngMax - grid.lngMin);
        
        const phi = (90 - latDeg) * (Math.PI / 180);
        const theta = (lngDeg + 180) * (Math.PI / 180);

        points.push({
          x: radius * Math.sin(phi) * Math.cos(theta),
          y: radius * Math.cos(phi),
          z: radius * Math.sin(phi) * Math.sin(theta),
          size: Math.random() * 2 + 1,
          alpha: Math.random() * 0.6 + 0.3
        });
      }
    });

    particlesRef.current = points;
  }, []);

  // Handle Resize of the container beautifully
  useEffect(() => {
    if (!containerRef.current) return;
    const observer = new ResizeObserver((entries) => {
      if (!entries || entries.length === 0) return;
      const { width } = entries[0].contentRect;
      const size = Math.max(320, Math.min(width, 540));
      setDimensions({ width: size, height: size });
    });
    observer.observe(containerRef.current);
    return () => observer.disconnect();
  }, []);

  // Main canvas animation loop
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    let animationFrameId: number;
    let pulseTime = 0;

    const render = () => {
      // Clear canvas with subtle radial alpha background
      ctx.clearRect(0, 0, dimensions.width, dimensions.height);
      ctx.save();

      // Translate origin to middle of canvas
      const cx = dimensions.width / 2;
      const cy = dimensions.height / 2;
      ctx.translate(cx, cy);

      pulseTime += 0.05;

      // Update rotation in Radians
      if (spin && !mouseRef.current.isDown) {
        rotationAngleRef.current += 0.0035;
      }
      const angle = rotationAngleRef.current;

      // Draw background atmospheric glow
      const radialGlow = ctx.createRadialGradient(0, 0, 100, 0, 0, 160);
      radialGlow.addColorStop(0, "rgba(31, 107, 58, 0.0)");
      radialGlow.addColorStop(0.7, "rgba(31, 107, 58, 0.06)");
      radialGlow.addColorStop(1, "rgba(212, 160, 23, 0.12)");
      ctx.fillStyle = radialGlow;
      ctx.beginPath();
      ctx.arc(0, 0, 160, 0, Math.PI * 2);
      ctx.fill();

      // Draw standard clean outer orbit line
      ctx.strokeStyle = "rgba(31, 107, 58, 0.15)";
      ctx.lineWidth = 1;
      ctx.beginPath();
      ctx.arc(0, 0, 150, 0, Math.PI * 2);
      ctx.stroke();

      // Project spherical points to 2D
      // Rotation operations are performed around the Y-axis
      const sinA = Math.sin(angle);
      const cosA = Math.cos(angle);

      const rotateY = (x: number, y: number, z: number) => {
        const rx = x * cosA - z * sinA;
        const rz = x * sinA + z * cosA;
        return { rx, ry: y, rz };
      };

      // Draw continent dot matrix
      const particles = particlesRef.current;
      for (const p of particles) {
        const { rx, ry, rz } = rotateY(p.x, p.y, p.z);
        // If particle is behind the horizon (Z <= 0), fade or draw dark
        if (rz < 0) continue;

        // Perspective scale modifier (subtle)
        const perspective = (rz + 150) / 300;
        const scale = 0.8 + perspective * 0.4;
        const screenX = rx * scale;
        const screenY = ry * scale;

        ctx.fillStyle = `rgba(31, 107, 58, ${p.alpha * (0.3 + perspective * 0.7)})`;
        ctx.beginPath();
        ctx.arc(screenX, screenY, p.size * scale, 0, Math.PI * 2);
        ctx.fill();
        
        // Highlight particle centers subtly in gold
        if (p.size > 2.0 && Math.random() > 0.99) {
          ctx.fillStyle = `rgba(212, 160, 23, ${perspective * 0.7})`;
          ctx.beginPath();
          ctx.arc(screenX, screenY, p.size * 0.5, 0, Math.PI * 2);
          ctx.fill();
        }
      }

      // Convert Latitude and Longitude to 3D Sphere cartesian
      const latLngToCartesian = (lat: number, lng: number) => {
        const r = 150;
        const phi = (90 - lat) * (Math.PI / 180);
        // Correct longitude offset based on standard map center
        const theta = (lng + 180) * (Math.PI / 180);
        return {
          x: r * Math.sin(phi) * Math.cos(theta),
          y: r * Math.cos(phi),
          z: r * Math.sin(phi) * Math.sin(theta)
        };
      };

      // Project and draw critical trade nodes
      const nodesToDraw = [
        { ...INDIA_COORDS, isOrigin: true },
        ...GLOBAL_HUBS.map(h => ({ ...h, isOrigin: false }))
      ];

      const projectedNodes: { [key: string]: { sx: number; sy: number; sz: number; name: string; isOrigin: boolean; raw: any } } = {};

      nodesToDraw.forEach(node => {
        const cartesian = latLngToCartesian(node.lat, node.lng);
        const { rx, ry, rz } = rotateY(cartesian.x, cartesian.y, cartesian.z);

        const perspective = (rz + 150) / 300;
        const scale = 0.8 + perspective * 0.4;
        const sx = rx * scale;
        const sy = ry * scale;

        projectedNodes[node.id || "india"] = { sx, sy, sz: rz, name: node.name, isOrigin: node.isOrigin, raw: node };
      });

      // Draw shipping/aircraft routes from India to chosen hubs
      const indiaProj = projectedNodes["india"];

      GLOBAL_HUBS.forEach(hub => {
        const hubProj = projectedNodes[hub.id];
        if (!indiaProj || !hubProj) return;

        // Check if both nodes or at least one is visible (sz > -50 for gentle curve wrap-around)
        if (indiaProj.sz < -20 && hubProj.sz < -20) return;

        const isHighlighted = selectedHub.id === hub.id;
        const routeOpacity = isHighlighted ? 0.9 : 0.35;
        
        ctx.beginPath();
        // Set curve path: quadratic bezier curve for dynamic arc
        ctx.moveTo(indiaProj.sx, indiaProj.sy);
        
        // Control point pulled outwards from earth core for 3D trajectory height
        const midX = (indiaProj.sx + hubProj.sx) / 2;
        const midY = (indiaProj.sy + hubProj.sy) / 2;
        const dist = Math.sqrt((indiaProj.sx - hubProj.sx) ** 2 + (indiaProj.sy - hubProj.sy) ** 2);
        
        // Offset normal vector outward
        const angleNormal = Math.atan2(hubProj.sy - indiaProj.sy, hubProj.sx - indiaProj.sx) - Math.PI / 2;
        const arcHeight = dist * 0.35;
        const ctrlX = midX + Math.cos(angleNormal) * arcHeight;
        const ctrlY = midY + Math.sin(angleNormal) * arcHeight;

        ctx.strokeStyle = isHighlighted ? "rgba(212, 160, 23, 0.75)" : "rgba(31, 107, 58, 0.4)";
        ctx.lineWidth = isHighlighted ? 2 : 1;
        
        // Set dashed pattern for inactive, solid for selected
        if (!isHighlighted) {
          ctx.setLineDash([4, 4]);
        } else {
          ctx.setLineDash([]);
        }

        ctx.quadraticCurveTo(ctrlX, ctrlY, hubProj.sx, hubProj.sy);
        ctx.stroke();
        ctx.setLineDash([]); // Reset line dash standard

        // Traveling light energy beam (cargo container transit visual)
        const travelPct = (pulseTime * 0.12) % 1; // loop percentage
        
        // Calculate point coordinate on quadratic bezier curve
        // B(t) = (1-t)^2 * P0 + 2(1-t)*t * P1 + t^2 * P2
        const t = travelPct;
        const mt = 1 - t;
        const px = mt * mt * indiaProj.sx + 2 * mt * t * ctrlX + t * t * hubProj.sx;
        const py = mt * mt * indiaProj.sy + 2 * mt * t * ctrlY + t * t * hubProj.sy;

        // Draw glowing transit container dot
        ctx.fillStyle = isHighlighted ? "#D4A017" : "#1F6B3A";
        ctx.beginPath();
        ctx.arc(px, py, isHighlighted ? 4 : 2.5, 0, Math.PI * 2);
        ctx.fill();

        // Draw mini beacon wave
        ctx.strokeStyle = isHighlighted ? "rgba(212, 160, 23, 0.5)" : "rgba(31, 107, 58, 0.3)";
        ctx.beginPath();
        ctx.arc(px, py, (pulseTime * 1.5) % 10 + 2, 0, Math.PI * 2);
        ctx.stroke();
      });

      // Render actual Hub dots on top of routes
      Object.keys(projectedNodes).forEach(key => {
        const pNode = projectedNodes[key];
        
        // Only draw nodes on front half of sphere
        if (pNode.sz < -30) return;

        const isHubTarget = !pNode.isOrigin;
        const isCurrentSelected = selectedHub.id === key;

        // Draw anchor node pulse ring
        if (pNode.isOrigin || isCurrentSelected) {
          ctx.strokeStyle = pNode.isOrigin ? "rgba(31, 107, 58, 0.8)" : "rgba(212, 160, 23, 0.8)";
          ctx.lineWidth = 1.5;
          ctx.beginPath();
          ctx.arc(pNode.sx, pNode.sy, 8 + Math.sin(pulseTime) * 3, 0, Math.PI * 2);
          ctx.stroke();
        }

        // Draw core node circle
        ctx.fillStyle = pNode.isOrigin 
          ? "#1F6B3A" 
          : (isCurrentSelected ? "#D4A017" : "#FFFFFF");
        ctx.strokeStyle = pNode.isOrigin ? "#FFFFFF" : "#1F6B3A";
        ctx.lineWidth = 2;
        ctx.beginPath();
        ctx.arc(pNode.sx, pNode.sy, pNode.isOrigin ? 6 : 4.5, 0, Math.PI * 2);
        ctx.fill();
        ctx.stroke();

        // Node Label
        if (pNode.isOrigin || isCurrentSelected) {
          ctx.fillStyle = "#1A1A1A";
          ctx.font = "bold 11px sans-serif";
          ctx.textAlign = "center";
          
          // Background capsule for readable name
          const txtLabel = pNode.raw.name;
          const textWidth = ctx.measureText(txtLabel).width;
          
          ctx.fillStyle = "rgba(255, 255, 255, 0.94)";
          ctx.strokeStyle = pNode.isOrigin ? "rgba(31, 107, 58, 0.3)" : "rgba(212, 160, 23, 0.6)";
          ctx.lineWidth = 1;
          
          // Round rect capsule background
          const capW = textWidth + 14;
          const capH = 18;
          const capX = pNode.sx - capW / 2;
          const capY = pNode.sy - 24;
          
          ctx.beginPath();
          ctx.arc(capX + 4, capY + 4, 4, Math.PI, Math.PI * 1.5);
          ctx.arc(capX + capW - 4, capY + 4, 4, Math.PI * 1.5, 0);
          ctx.arc(capX + capW - 4, capY + capH - 4, 4, 0, Math.PI * 0.5);
          ctx.arc(capX + 4, capY + capH - 4, 4, Math.PI * 0.5, Math.PI);
          ctx.closePath();
          ctx.fill();
          ctx.stroke();

          ctx.fillStyle = pNode.isOrigin ? "#1F6B3A" : "#1A1A1A";
          ctx.fillText(txtLabel, pNode.sx, pNode.sy - 12);
        }
      });

      ctx.restore();
      animationFrameId = requestAnimationFrame(render);
    };

    render();

    return () => {
      cancelAnimationFrame(animationFrameId);
    };
  }, [dimensions, spin, selectedHub]);

  // Touch and mouse manual spin handler
  const handleMouseDown = (e: React.MouseEvent) => {
    mouseRef.current.isDown = true;
    mouseRef.current.lastX = e.clientX;
  };

  const handleMouseMove = (e: React.MouseEvent) => {
    if (!mouseRef.current.isDown) return;
    const deltaX = e.clientX - mouseRef.current.lastX;
    rotationAngleRef.current += deltaX * 0.007;
    mouseRef.current.lastX = e.clientX;
  };

  const handleMouseUpOrLeave = () => {
    mouseRef.current.isDown = false;
  };

  return (
    <div className="flex flex-col xl:flex-row items-center gap-8 w-full max-w-6xl mx-auto py-4">
      {/* Globe Canvas Column */}
      <div 
        ref={containerRef}
        className="relative flex items-center justify-center bg-radial from-slate-50 to-emerald-50/25 border border-emerald-900/10 rounded-3xl p-6 shadow-sm overflow-hidden w-full max-w-[500px] xl:max-w-[480px] aspect-square"
        onMouseDown={handleMouseDown}
        onMouseMove={handleMouseMove}
        onMouseUp={handleMouseUpOrLeave}
        onMouseLeave={handleMouseUpOrLeave}
      >
        <canvas 
          ref={canvasRef}
          width={dimensions.width}
          height={dimensions.height}
          className="cursor-grab active:cursor-grabbing max-w-full block"
        />

        {/* Floating Manual Spinning Trigger */}
        <div className="absolute top-4 left-4 z-10 flex gap-2">
          <button 
            id="it_interactive_spin_toggle"
            onClick={() => setSpin(!spin)}
            className="flex items-center gap-1.5 px-3 py-1 bg-white/95 border border-emerald-900/15 text-[11px] font-mono font-medium rounded-full text-emerald-900 shadow-xs hover:bg-emerald-50 transition"
          >
            <Compass className={`w-3.5 h-3.5 ${spin ? "animate-spin" : ""}`} />
            {spin ? "Auto-Orbiting" : "Manual Rotation"}
          </button>
        </div>

        {/* Global Coordinates Status Overlay */}
        <div className="absolute bottom-4 left-4 z-10 bg-white/95 border border-emerald-900/10 backdrop-blur-md rounded-xl p-2.5 text-[10px] font-mono text-slate-500 shadow-xs leading-normal">
          <div className="text-emerald-800 font-bold mb-0.5">ORIGIN COMPLIANCE</div>
          <div>PORT: JNPT, Nhava Sheva (IN)</div>
          <div>LAT: 20.1053° N</div>
          <div>LNG: 73.8871° E</div>
        </div>

        {/* Instructions */}
        <div className="absolute bottom-4 right-4 z-10 bg-black/5 opacity-70 border border-black/10 rounded-full px-2 py-0.5 text-[9px] font-sans text-slate-800 shadow-xs">
          Drag to spin globe
        </div>
      </div>

      {/* Interactive Shipping Routes Detail Board */}
      <div className="flex-1 w-full bg-white border border-emerald-900/10 rounded-3xl p-6 shadow-sm flex flex-col justify-between">
        <div>
          <div className="flex items-center gap-2 mb-2 text-xs font-mono font-bold tracking-widest text-[#D4A017] uppercase">
            <Globe2 className="w-4 h-4" /> Global Dispatch Network
          </div>
          <h3 className="text-2xl font-semibold tracking-tight text-slate-900 font-sans mb-3">
            Real-Time Logistics & Market Support
          </h3>
          <p className="text-sm font-sans text-slate-600 mb-6">
            We operate fully audited commercial shipping lanes from India's west coast (Nhava Sheva Sea Port / Mumbai Air Terminal) guaranteeing container security, standard humidity controls, and custom clearance documents.
          </p>

          {/* Quick Hub Filter Tabs */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-1.5 mb-6">
            {GLOBAL_HUBS.map((hub) => (
              <button
                key={hub.id}
                id={`hub_tab_${hub.id}`}
                onClick={() => setSelectedHub(hub)}
                className={`px-3 py-2 text-xs font-medium font-sans rounded-xl border text-left transition ${
                  selectedHub.id === hub.id
                    ? "bg-[#1F6B3A] text-white border-[#1F6B3A] shadow-xs"
                    : "bg-emerald-50/40 text-slate-700 border-emerald-900/10 hover:bg-emerald-50/80"
                }`}
              >
                {hub.name}
              </button>
            ))}
          </div>

          {/* Detailed Selected Hub Display Card */}
          <div className="bg-[#F7F9F8] border border-emerald-900/5 rounded-2xl p-5 mb-5 space-y-4">
            <div className="flex items-start justify-between">
              <div>
                <h4 className="text-lg font-bold text-slate-900 font-sans">{selectedHub.name} Link</h4>
                <p className="text-xs text-slate-500 font-mono mt-0.5">{selectedHub.label}</p>
              </div>
              <span className="inline-flex items-center px-2.5 py-0.5 bg-emerald-100 text-emerald-800 text-[10px] font-medium font-sans rounded-full">
                Active Route
              </span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 pt-2 border-t border-slate-200">
              <div className="space-y-1">
                <span className="flex items-center gap-1 text-[11px] font-mono text-slate-500 uppercase tracking-wider">
                  <Plane className="w-3.5 h-3.5 text-[#1F6B3A]" /> Priority Air
                </span>
                <p className="text-sm font-semibold text-slate-800 font-sans">{selectedHub.transitAir}</p>
                <p className="text-[10px] text-slate-400">Direct courier or belly cargo</p>
              </div>

              <div className="space-y-1">
                <span className="flex items-center gap-1 text-[11px] font-mono text-slate-500 uppercase tracking-wider">
                  <Ship className="w-3.5 h-3.5 text-[#D4A017]" /> Standard Sea
                </span>
                <p className="text-sm font-semibold text-slate-800 font-sans">{selectedHub.transitSea}</p>
                <p className="text-[10px] text-slate-400">FCL & LCL consolidated loads</p>
              </div>

              <div className="space-y-1">
                <span className="flex items-center gap-1 text-[11px] font-mono text-slate-500 uppercase tracking-wider">
                  <Anchor className="w-3.5 h-3.5 text-[#1F6B3A]" /> Primary Ports
                </span>
                <p className="text-sm font-semibold text-slate-800 font-sans">{selectedHub.port}</p>
                <p className="text-[10px] text-slate-400">Standard customs clearing hubs</p>
              </div>
            </div>
          </div>
        </div>

        {/* Global Compliance Note */}
        <div className="flex items-start gap-2 text-xs text-emerald-950/80 bg-emerald-50/50 rounded-xl p-3 border border-emerald-900/10 font-sans">
          <AlertCircle className="w-4 h-4 text-[#D4A017] shrink-0 mt-0.5" />
          <span>
            <strong>B2B Delivery Notice:</strong> All herbal, fruit and vegetable cargos are stored and transported with food-grade moisture absorbers. Micro-specifications and organic COAs are prepared before container dispatch.
          </span>
        </div>
      </div>
    </div>
  );
}
