/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from "react";
import { X, FileText, Scale, ShieldCheck } from "lucide-react";

interface ModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export function PrivacyPolicyModal({ isOpen, onClose }: ModalProps) {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs animate-fade-in">
      <div className="bg-white border border-[#1F6B3A]/10 rounded-3xl w-full max-w-3xl max-h-[85vh] overflow-hidden flex flex-col shadow-2xl">
        
        {/* Header */}
        <div className="px-6 py-4.5 bg-[#1F6B3A] text-white flex justify-between items-center shrink-0">
          <div className="flex items-center gap-2">
            <ShieldCheck className="w-5 h-5 text-[#D4A017]" />
            <h3 className="font-display font-bold text-lg">International B2B Privacy Policy</h3>
          </div>
          <button 
            onClick={onClose}
            className="p-1 text-white/80 hover:text-white hover:bg-emerald-800 rounded-full transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Scrollable Body */}
        <div className="p-6 overflow-y-auto space-y-5 text-sm text-slate-650 leading-relaxed font-sans">
          <p className="text-xs text-[#1F6B3A] font-mono font-bold uppercase tracking-wide">
            Last Updated: June 19, 2026 | KanhaiyaExim Export Compliance
          </p>
          
          <p>
            At <strong>KanhaiyaExim</strong>, a primary merchant exporter and sourcing partner located in Janori, Nashik, India, we understand the paramount importance of data discretion and confidentiality in global B2B procurement. This Privacy Policy governs the collection, storage, security, and usage of communications and commercial information shared with us relative to international trade.
          </p>

          <hr className="border-slate-150" />

          <div className="space-y-2">
            <h4 className="font-bold font-display text-slate-900 text-sm">1. Information We Collect</h4>
            <p>
              We collect corporate and transaction-level details as submitted voluntarily through our B2B quotation portals, inquiries, or telephone logs. This includes: Commercial Contact Name, Corporate Brand Title, Registration metrics, Email, Phone, WhatsApp ID, Product Specifications, Target Ship Weight, target Packaging Formats, and designated maritime delivery ports.
            </p>
          </div>

          <div className="space-y-2">
            <h4 className="font-bold font-display text-slate-900 text-sm">2. Sourcing Data Usage</h4>
            <p>
              Your shared operational details are strictly utilized to: formulate valid B2B commercial invoices and FOB/CIF price grids; coordinate cargo bookings with authorized maritime shipping liners; compile export documentation (e.g., Phytosanitary, Certification of Origin); and maintain clear communication.
            </p>
          </div>

          <div className="space-y-2">
            <h4 className="font-bold font-display text-slate-900 text-sm">3. Cookies & Analytical Tracing</h4>
            <p>
              Our website utilizes minimal, secure, and cookie-based tools purely to preserve operational state, such as retaining items drafted inside your active Sourcing Cart. We do not engage in invasive behavioral tracking or sell user data to secondary advertisement services.
            </p>
          </div>

          <div className="space-y-2">
            <h4 className="font-bold font-display text-slate-900 text-sm">4. Data Security & Storage Integrity</h4>
            <p>
              All submitted data, product formulas, and ingredient specifications are stored securely. Information is only shared with authorized custom inspectors, crop verification labs, or freight forwarding agents strictly to carry out export obligations.
            </p>
          </div>

          <div className="space-y-2">
            <h4 className="font-bold font-display text-slate-900 text-sm">5. Technical Confidentiality & Proprietary Recipe Protection</h4>
            <p>
              For buyers utilizing our <strong>OEM & Private Label Services</strong>: any custom ingredient formulas, mix-ratios, target moisture metrics, or proprietary branding artwork shared remain the exclusive property of the buyer. KanhaiyaExim enforces strict non-disclosure obligations throughout our manufacturing coordinates in Nashik.
            </p>
          </div>

          <div className="space-y-2">
            <h4 className="font-bold font-display text-slate-900 text-sm">6. Third-Party Shipping Logistics</h4>
            <p>
              Under CFR/CIF shipping arrangements, required packing lists and freight manifests are shared exclusively with trusted first-tier maritime shipping lines or domestic transport fleets.
            </p>
          </div>

          <div className="space-y-2">
            <h4 className="font-bold font-display text-slate-900 text-sm">7. Official Contact Desk</h4>
            <p>
              For any questions regarding custom clearances or privacy protocols, please contact our Legal Officer at:
              <br />
              <strong>Email:</strong> <span className="font-mono text-[13px] text-emerald-800">kanhaiyaexim@yahoo.com</span>
              <br />
              <strong>Address:</strong> Janori, Nashik, Maharashtra – 422206, India.
            </p>
          </div>
        </div>

        {/* Footer */}
        <div className="px-6 py-4 bg-slate-50 border-t border-slate-100 flex justify-end shrink-0">
          <button 
            onClick={onClose}
            className="px-5 py-2.5 bg-[#1F6B3A] hover:bg-emerald-800 text-white text-xs font-bold leading-normal font-display uppercase tracking-wider rounded-xl transition"
          >
            Acknowledge Clause
          </button>
        </div>

      </div>
    </div>
  );
}

export function TermsConditionsModal({ isOpen, onClose }: ModalProps) {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs animate-fade-in">
      <div className="bg-white border border-emerald-900/10 rounded-3xl w-full max-w-3xl max-h-[85vh] overflow-hidden flex flex-col shadow-2xl">
        
        {/* Header */}
        <div className="px-6 py-4.5 bg-[#1F6B3A] text-white flex justify-between items-center shrink-0">
          <div className="flex items-center gap-2">
            <Scale className="w-5 h-5 text-[#D4A017]" />
            <h3 className="font-display font-bold text-lg">Trade Terms & Conditions (B2B Export)</h3>
          </div>
          <button 
            onClick={onClose}
            className="p-1 text-white/80 hover:text-white hover:bg-emerald-800 rounded-full transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Scrollable Body */}
        <div className="p-6 overflow-y-auto space-y-5 text-sm text-slate-650 leading-relaxed font-sans">
          <p className="text-xs text-[#1F6B3A] font-mono font-bold uppercase tracking-wide">
            Effective Standard: June 19, 2026 | KanhaiyaExim Export Framework
          </p>

          <p>
            Welcome to the commercial B2B platform of <strong>KanhaiyaExim</strong>. The trade terms, specifications, and commercial agreements described below govern all standard pricing, procurement operations, sample dispatches, and export deliveries issued from our corporate dispatch center in Nashik.
          </p>

          <hr className="border-slate-150" />

          <div className="space-y-2">
            <h4 className="font-bold font-display text-slate-900 text-sm">1. Nature of Business Operations</h4>
            <p>
              KanhaiyaExim operates as a registered <strong>Merchant Exporter & Sourcing Partner</strong> under Indian Trade regulations (IEC: DAVPT2930Q). We source select crops, dehydrate, process, custom-mesh, and pack vegetable, fruit, herbal, and tea/coffee powders through certified, fully-vetted manufacturing partners in the Nashik agricultural sector.
            </p>
          </div>

          <div className="space-y-2">
            <h4 className="font-bold font-display text-slate-900 text-sm">2. Sourcing Quotations & Pricing Validity</h4>
            <p>
              All prices issued are in United States Dollars (USD) or Euros (EUR) and are valid for a maximum of 14 calendar days from the date of quotation. Due to seasonal fluctuations in agricultural crops, raw material cost indexes, and marine transport tariffs, final price matrices must be locked in writing via a formal Proforma Invoice (PI) prior to production orders.
            </p>
          </div>

          <div className="space-y-2">
            <h4 className="font-bold font-display text-slate-900 text-sm">3. Order Placement & MOQ Grid</h4>
            <p>
              Our standard wholesale Minimum Order Quantity (MOQ) is <strong>250 kg</strong> per ingredient. Customized blends or private-label retail packing runs have custom MOQs (typically 500 kg to 1 Ton) depending on specific pouch material printing configurations.
            </p>
          </div>

          <div className="space-y-2">
            <h4 className="font-bold font-display text-slate-900 text-sm">4. Botanical and Chemical Specifications</h4>
            <p>
              Ingredient standards (such as mesh sizing, humidity density, bacterial specifications, and active extract percentages) are detailed in our official Certificate of Analysis (COA) issued for each batch. The buyer is responsible for verifying that the technical specifications conform with their local food safety laws and import rules before container packing begins.
            </p>
          </div>

          <div className="space-y-2">
            <h4 className="font-bold font-display text-slate-900 text-sm">5. Commercial Payment Terms</h4>
            <p>
              Recognizing international trading security, our standard B2B terms include:
              <br />
              <strong>A. Advance T/T:</strong> 30% advance deposit to initiate sourcing and processing, with the remaining 70% paid against digital copies of clean Bills of Lading (B/L) and shipping documents.
              <br />
              <strong>B. Documentary Letters of Credit (L/C):</strong> Supported for established credit-verified buyers, subject to specific bank validations and high transaction volumes.
            </p>
          </div>

          <div className="space-y-2">
            <h4 className="font-bold font-display text-slate-900 text-sm">6. Maritime Shipping, Packing, and Container Deliveries</h4>
            <p>
              We coordinate global maritime exports based on ICC Incoterms (specifically FOB JNP/Chennai, CFR, or CIF). Title of goods transfers to the buyer upon secure cargo onboarding on the shipping vessel at the Indian port. All vegetable, fruit, and spice powders are loaded inside heavy-duty multi-layer polybags or airtight HDPE drums with moisture absorbers inside.
            </p>
          </div>

          <div className="space-y-2">
            <h4 className="font-bold font-display text-slate-900 text-sm">7. Sifting, Claims & Weight Discrepancies</h4>
            <p>
              In the rare event of chemical, mesh-size, or moisture deviations, any claims must be submitted to our team within 15 calendar days of cargo arrival at the target port of entry. Claims must be supported by an official inspection report compiled by a registered third-party evaluation lab (e.g., SGS, Bureau Veritas). Our liability is strictly limited to replacing the non-conforming batch or issuing a credit note.
            </p>
          </div>

          <div className="space-y-2">
            <h4 className="font-bold font-display text-slate-900 text-sm">8. Force Majeure Protection</h4>
            <p>
              Neither party shall be held liable for failure or delays in performing our trade obligations caused by events beyond reasonable control, including agricultural crop failures, extreme monsoon floods, ocean shipping port strikes, maritime container blockades, government trade bans, or geopolitical shifts.
            </p>
          </div>

          <div className="space-y-2">
            <h4 className="font-bold font-display text-slate-900 text-sm">9. Buyer & Seller Sourcing Responsibilities</h4>
            <p>
              The Seller (KanhaiyaExim) is responsible for supplying products that conform with agreed COAs, packing securely, and acquiring phytosanitary clearance at the Indian port. The Buyer is responsible for checking local food regulatory standards, import customs procedures, paying local import terminal taxes, and arranging smooth container drayage.
            </p>
          </div>

          <div className="space-y-2">
            <h4 className="font-bold font-display text-slate-900 text-sm">10. Governing Law & Indian Jurisdiction</h4>
            <p>
              These Terms and Conditions and all operations, quotations, and export transactions of KanhaiyaExim are governed by and construed in accordance with the Laws of India. Any unresolved disputes shall be subject to the exclusive legal jurisdiction of the competent Courts at <strong>Nashik, Maharashtra, India</strong>.
            </p>
          </div>
        </div>

        {/* Footer */}
        <div className="px-6 py-4 bg-slate-50 border-t border-slate-100 flex justify-end shrink-0">
          <button 
            onClick={onClose}
            className="px-5 py-2.5 bg-[#1F6B3A] hover:bg-emerald-800 text-white text-xs font-bold leading-normal font-display uppercase tracking-wider rounded-xl transition"
          >
            Acknowledge Terms
          </button>
        </div>

      </div>
    </div>
  );
}
