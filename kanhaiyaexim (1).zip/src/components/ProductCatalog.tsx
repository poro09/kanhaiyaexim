/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useMemo } from "react";
import { Search, Plus, Check, Star, CornerDownRight, Leaf, ShieldCheck, HelpCircle, ArrowUpRight, Award, Flame, Filter, Zap } from "lucide-react";
import { PRODUCT_CATEGORIES, Product, ProductGroup } from "../data";

interface RfqItem {
  product: Product;
  quantityValue: number;
  quantityUnit: string;
  packagingType: string;
}

interface ProductCatalogProps {
  rfqItems: RfqItem[];
  addRfqItem: (prod: Product) => void;
  removeRfqItem: (id: string) => void;
}

export default function ProductCatalog({ rfqItems, addRfqItem, removeRfqItem }: ProductCatalogProps) {
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedCategoryId, setSelectedCategoryId] = useState("all");

  // Flat helper list of all products for search
  const allProductsFlat = useMemo(() => {
    const list: (Product & { catName: string; catId: string })[] = [];
    PRODUCT_CATEGORIES.forEach(cat => {
      cat.products.forEach(p => {
        list.push({ ...p, catName: cat.name, catId: cat.id });
      });
    });
    return list;
  }, []);

  // Filtered list based on search and category tab
  const filteredProducts = useMemo(() => {
    return allProductsFlat.filter(p => {
      const matchSearch = p.name.toLowerCase().includes(searchTerm.toLowerCase()) || 
                          p.description.toLowerCase().includes(searchTerm.toLowerCase());
      const matchCategory = selectedCategoryId === "all" || p.catId === selectedCategoryId;
      return matchSearch && matchCategory;
    });
  }, [allProductsFlat, searchTerm, selectedCategoryId]);

  // Check if a product is inside RFQ
  const isProductInRfq = (id: string) => {
    return rfqItems.some(item => item.product.id === id);
  };

  const handleRfqToggle = (product: Product) => {
    if (isProductInRfq(product.id)) {
      removeRfqItem(product.id);
    } else {
      addRfqItem(product);
    }
  };

  return (
    <section className="py-12 bg-[#F7F9F8] border-b border-slate-200">
      <div className="max-w-7xl mx-auto px-4 md:px-8">
        
        {/* Flagship Specialty Feature Card: Moringa Leaf Powder */}
        <div className="mb-14 overflow-hidden rounded-3xl border border-emerald-900/10 shadow-lg relative bg-white">
          <div className="absolute top-0 right-0 w-64 h-64 bg-emerald-500/5 rounded-full blur-3xl pointer-events-none" />
          <div className="absolute bottom-0 left-0 w-80 h-80 bg-amber-500/5 rounded-full blur-3xl pointer-events-none" />
          
          <div className="grid grid-cols-1 lg:grid-cols-12">
            {/* Visual Intro */}
            <div className="lg:col-span-5 bg-gradient-to-br from-[#1F6B3A] to-[#144726] p-8 md:p-12 text-white flex flex-col justify-between relative overflow-hidden">
              <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top_right,_var(--tw-gradient-stops))] from-amber-500/10 via-transparent to-transparent pointer-events-none" />
              
              <div>
                <span className="inline-flex items-center gap-1.5 px-3 py-1 bg-[#D4A017]/90 text-white text-[11px] font-bold font-mono tracking-wider uppercase rounded-full mb-6">
                  <Star className="w-3.5 h-3.5 fill-[#FFFFFF]" /> Flagship Export Line
                </span>
                <h3 className="text-3xl md:text-4xl font-extrabold tracking-tight font-display text-white mb-4 leading-tight">
                  Moringa Leaf Powder
                </h3>
                <p className="text-sm text-emerald-100/90 leading-relaxed font-sans mb-6">
                  Regarded as one of the world's most nutrient-dense botanicals, our Moringa Oleifera is harvested during peak growth periods, gently shadow-dehydrated, and pulverized to a perfect 120-mesh premium product.
                </p>
              </div>

              {/* Verified Metrics */}
              <div className="space-y-4 pt-6 border-t border-emerald-800/60 font-mono">
                <div className="flex justify-between text-xs text-emerald-200">
                  <span>Standard Mesh size:</span>
                  <span className="font-bold text-white">120+ Super-Fine</span>
                </div>
                <div className="flex justify-between text-xs text-emerald-200">
                  <span>Moisture Limit:</span>
                  <span className="font-bold text-white">&lt; 8.0% Max</span>
                </div>
                <div className="flex justify-between text-xs text-emerald-200">
                  <span>Heavy Metal Profile:</span>
                  <span className="font-bold text-[#D4A017]">Zero Preservatives</span>
                </div>
              </div>
            </div>

            {/* Technical Detail Sheet */}
            <div className="lg:col-span-7 p-8 md:p-12 flex flex-col justify-between">
              <div>
                <div className="flex items-center justify-between mb-4 border-b border-slate-100 pb-3">
                  <span className="text-xs font-bold text-[#1F6B3A] font-mono uppercase tracking-widest">Sourcing Specifications</span>
                  <span className="text-xs font-mono text-slate-500">HS Code: 1211.90</span>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
                  <div>
                    <h4 className="text-xs font-bold text-slate-900 font-sans uppercase tracking-wider mb-2">Key Nutritional Density</h4>
                    <ul className="space-y-1.5 text-xs text-slate-600 font-sans">
                      <li className="flex items-center gap-2"><CornerDownRight className="w-3.5 h-3.5 text-[#D4A017]" /> High Protein & Essential Amino Acids</li>
                      <li className="flex items-center gap-2"><CornerDownRight className="w-3.5 h-3.5 text-[#D4A017]" /> 25x Bio-Available Iron of Spinach</li>
                      <li className="flex items-center gap-2"><CornerDownRight className="w-3.5 h-3.5 text-[#D4A017]" /> High Potency Antioxidants (Zatin)</li>
                    </ul>
                  </div>

                  <div>
                    <h4 className="text-xs font-bold text-slate-900 font-sans uppercase tracking-wider mb-2">Primary Global Applications</h4>
                    <ul className="space-y-1.5 text-xs text-slate-600 font-sans">
                      <li className="flex items-center gap-2"><Check className="w-3.5 h-3.5 text-emerald-600" /> Nutraceutical Supplement Formulations</li>
                      <li className="flex items-center gap-2"><Check className="w-3.5 h-3.5 text-emerald-600" /> Organic Green Food & Beverage Blends</li>
                      <li className="flex items-center gap-2"><Check className="w-3.5 h-3.5 text-emerald-600" /> Botanical Skin Cosmetics Extracts</li>
                    </ul>
                  </div>
                </div>

                {/* Packaging & Compliance Bar */}
                <div className="bg-[#F7F9F8] border border-slate-200 rounded-xl p-4 flex flex-col sm:flex-row justify-between gap-4 items-center">
                  <div className="text-xs">
                    <p className="font-semibold text-slate-800">Available Packaging</p>
                    <p className="text-slate-500 mt-0.5">25kg Kraft Bags / Secure HDPE Drums</p>
                  </div>
                  <div className="text-xs sm:text-right">
                    <p className="font-semibold text-slate-800">Compliance Certification</p>
                    <p className="text-slate-500 mt-0.5">Phytosanitary & SGS Analysis Ready</p>
                  </div>
                </div>
              </div>

              {/* Action Trigger */}
              <div className="pt-6 border-t border-slate-100 flex flex-col sm:flex-row justify-between items-center gap-4 mt-6">
                <div className="flex items-center gap-2 text-xs text-slate-500">
                  <ShieldCheck className="w-4 h-4 text-[#1F6B3A]" />
                  <span>Sourced directly from dedicated local farming zones in Maharashtra, India.</span>
                </div>
                
                <button
                  id="flagship_moringa_rfq_btn"
                  onClick={() => {
                    const moringaProd = PRODUCT_CATEGORIES[0].products[0];
                    handleRfqToggle(moringaProd);
                  }}
                  className={`w-full sm:w-auto px-6 py-3 text-xs font-bold font-display uppercase tracking-wider rounded-xl transition cursor-pointer flex items-center justify-center gap-2 shadow-xs ${
                    isProductInRfq("moringa-leaf-powder-flagship")
                      ? "bg-emerald-100 text-emerald-800 border-2 border-emerald-500"
                      : "bg-[#1F6B3A] text-white hover:bg-emerald-800 border border-emerald-950/20"
                  }`}
                >
                  {isProductInRfq("moringa-leaf-powder-flagship") ? (
                    <>
                      <Check className="w-4 h-4" /> Added to Sourcing Draft
                    </>
                  ) : (
                    <>
                      <Plus className="w-4 h-4" /> Add to Sourcing Draft
                    </>
                  )}
                </button>
              </div>
            </div>
          </div>
        </div>

        {/* Search & Modular Filter Controls Header */}
        <div className="mb-8 space-y-6">
          <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4 py-4 border-b border-slate-200">
            <div>
              <span className="text-xs font-mono font-bold uppercase tracking-wider text-[#D4A017]">IMPORTERS INGREDIENT HUB</span>
              <h4 className="text-2xl font-bold text-slate-900 tracking-tight font-display mt-0.5">Explore Our Powder Portfolio</h4>
            </div>

            {/* Compact Search Bar with SVG Magnifier */}
            <div className="relative w-full md:max-w-md">
              <input
                id="catalog_search_input"
                type="text"
                placeholder="Search premium vegetable, fruit, spices, and tea extracts..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full bg-white border border-slate-300 rounded-2xl pl-11 pr-4 py-3 text-sm text-slate-905 placeholder-slate-400 focus:outline-hidden focus:ring-2 focus:ring-[#1F6B3A] focus:border-transparent shadow-xs transition"
              />
              <Search className="absolute left-4 top-3.5 w-4.5 h-4.5 text-slate-400" />
              {searchTerm && (
                <button 
                  onClick={() => setSearchTerm("")}
                  className="absolute right-4 top-3.5 text-xs text-slate-400 hover:text-[#1F6B3A]"
                >
                  Clear
                </button>
              )}
            </div>
          </div>

          {/* Sourcing Category Tabs */}
          <div className="flex flex-wrap items-center gap-1.5 pb-2 overflow-x-auto select-none no-scrollbar">
            <button
              id="cat_tab_all"
              onClick={() => setSelectedCategoryId("all")}
              className={`px-4 py-2.5 rounded-xl text-xs font-semibold font-sans tracking-wide transition ${
                selectedCategoryId === "all"
                  ? "bg-[#1F6B3A] text-white shadow-xs"
                  : "bg-white border border-slate-300 text-slate-700 hover:bg-slate-50"
              }`}
            >
              All Powders ({allProductsFlat.length})
            </button>
            
            {PRODUCT_CATEGORIES.map((cat) => (
              <button
                key={cat.id}
                id={`cat_tab_btn_${cat.id}`}
                onClick={() => setSelectedCategoryId(cat.id)}
                className={`px-4 py-2.5 rounded-xl text-xs font-semibold font-sans tracking-wide transition flex items-center gap-1.5 whitespace-nowrap ${
                  selectedCategoryId === cat.id
                    ? "bg-[#1F6B3A] text-white shadow-xs"
                    : "bg-white border border-slate-300 text-slate-700 hover:bg-slate-50"
                }`}
              >
                <span>{cat.name}</span>
                <span className="text-[10px] bg-slate-100 text-slate-600 px-1.5 py-0.5 rounded-full font-mono">
                  {cat.products.length}
                </span>
              </button>
            ))}
          </div>
        </div>

        {/* Results Counter / Warning */}
        <div className="mb-6 flex justify-between items-center text-xs text-slate-500 font-mono">
          <span>SHOWING {filteredProducts.length} GRADES MATCHING TARGET CRITERIA</span>
          {searchTerm && (
            <span>FILTER ACTIVE: "{searchTerm}"</span>
          )}
        </div>

        {/* Grid of Dehydrated Powders Cards */}
        {filteredProducts.length === 0 ? (
          <div className="bg-white border border-slate-200 rounded-3xl p-12 text-center max-w-lg mx-auto shadow-sm">
            <HelpCircle className="w-12 h-12 text-[#D4A017] mx-auto mb-4" />
            <h5 className="text-base font-bold text-slate-800">No matching ingredients found</h5>
            <p className="text-xs text-slate-500 mt-1 mb-6 leading-normal font-sans">
              We offer bespoke formulation capabilities and custom powder milling from Nashik. Tell us your requested agricultural product, mesh specifications, and target packaging.
            </p>
            <button
              onClick={() => {
                setSearchTerm("");
                setSelectedCategoryId("all");
              }}
              className="px-4 py-2 bg-[#1F6B3A] text-white text-xs font-bold rounded-xl"
            >
              Reset Filters
            </button>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredProducts.map((p) => {
              const inCart = isProductInRfq(p.id);
              
              return (
                <div
                  key={p.id}
                  id={`product_card_${p.id}`}
                  className={`bg-white border rounded-2xl p-5 shadow-xs flex flex-col justify-between transition-all duration-300 relative group h-full ${
                    inCart
                      ? "border-[#1F6B3A] ring-1 ring-[#1F6B3A]/25"
                      : "border-slate-300 hover:border-emerald-600 hover:shadow-md"
                  }`}
                >
                  {/* Subtle Badge Highlights on Hover */}
                  <div className="absolute top-4 right-4 flex items-center gap-1.5 opacity-0 group-hover:opacity-100 transition duration-300 pointer-events-none">
                    <span className="text-[9px] font-mono font-bold tracking-widest bg-emerald-50 text-emerald-900 border border-emerald-900/10 px-1.5 py-0.5 rounded-md uppercase">
                      B2B Bulk
                    </span>
                    <span className="text-[9px] font-mono font-bold tracking-widest bg-amber-50 text-amber-900 border border-[#D4A017]/20 px-1.5 py-0.5 rounded-md uppercase">
                      COA OK
                    </span>
                  </div>

                  <div>
                    {/* Category Label */}
                    <span className="text-[10px] font-mono font-bold tracking-wider text-slate-400 uppercase">
                      {p.catName}
                    </span>

                    {/* Headline */}
                    <h5 className="text-base font-bold text-slate-900 font-sans tracking-tight leading-snug mt-1 group-hover:text-[#1F6B3A] transition">
                      {p.name}
                    </h5>

                    {/* Description */}
                    <p className="text-xs text-slate-500 leading-relaxed font-sans mt-2.5">
                      {p.description}
                    </p>

                    {/* Specs Pills */}
                    <div className="mt-4 flex flex-wrap gap-1">
                      <span className="text-[10px] bg-slate-100 text-slate-600 px-2 py-0.5 rounded-md font-sans">
                        Hygienic Dehydration
                      </span>
                      <span className="text-[10px] bg-[#1F6B3A]/5 text-emerald-900 px-2 py-0.5 rounded-md font-sans">
                        Sourcing Grade
                      </span>
                    </div>
                  </div>

                  {/* Actions Area */}
                  <div className="pt-4 mt-5 border-t border-slate-100 flex items-center justify-between">
                    <span className="text-[10px] font-mono text-slate-400 select-none">
                      HS Code: {p.id.startsWith("black-") || p.id.startsWith("spray-") || p.id.startsWith("instant-") || p.id.startsWith("coffee-") ? "0901.21" : "0712.90"}
                    </span>

                    <button
                      id={`rfq_toggle_btn_${p.id}`}
                      onClick={() => handleRfqToggle(p)}
                      className={`px-3.5 py-2 rounded-xl text-xs font-semibold font-display tracking-wide uppercase transition cursor-pointer flex items-center gap-1 ${
                        inCart
                          ? "bg-emerald-100 text-emerald-800 border border-emerald-500"
                          : "bg-white border border-slate-300 text-[#1F6B3A] hover:bg-emerald-500 hover:text-white hover:border-emerald-500"
                      }`}
                    >
                      {inCart ? (
                        <>
                          <Check className="w-3.5 h-3.5" /> Drafting
                        </>
                      ) : (
                        <>
                          <Plus className="w-3.5 h-3.5" /> + Sourcing Cart
                        </>
                      )}
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        )}

        {/* Custom Formulations Banner */}
        <div className="mt-12 bg-linear-to-r from-[#1F6B3A] to-[#144726] rounded-3xl p-6 md:p-8 text-white relative overflow-hidden shadow-sm border border-emerald-950/20">
          <div className="absolute top-0 right-0 w-80 h-full bg-linear-to-l from-amber-500/10 to-transparent pointer-events-none" />
          
          <div className="max-w-3xl flex flex-col md:flex-row md:items-center justify-between gap-6">
            <div className="space-y-2">
              <span className="inline-flex items-center gap-1 px-2.5 py-0.5 bg-[#D4A017]/90 text-white text-[10px] font-bold font-mono uppercase tracking-wider rounded-lg">
                <Flame className="w-3.5 h-3.5 text-white" /> Bespoke Formulations
              </span>
              <h4 className="text-xl md:text-2xl font-bold font-display tracking-tight text-white leading-tight">
                Require Custom Blend Ratios or Custom Label Packaging?
              </h4>
              <p className="text-xs text-emerald-100/90 leading-relaxed font-sans">
                Our operations & testing labs in Janori, Nashik accommodate tailor-made mesh ranges, specific moisture limits, private label retail bag counts, and custom agricultural powder blends.
              </p>
            </div>
            
            <button
              onClick={() => {
                const quoteEl = document.getElementById("quote_form_section");
                if (quoteEl) quoteEl.scrollIntoView({ behavior: "smooth" });
              }}
              className="px-5 py-3 bg-[#D4A017] hover:bg-amber-600 text-white text-xs font-bold font-display uppercase tracking-wider rounded-xl shadow-xs shrink-0 self-start md:self-center transition border border-amber-500"
            >
              Contact Chemists
            </button>
          </div>
        </div>

      </div>
    </section>
  );
}
