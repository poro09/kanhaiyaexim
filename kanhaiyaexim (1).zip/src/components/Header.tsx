/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from "react";
import { Ship, ShoppingCart, Trash2, X, ChevronRight, FileHeart, Briefcase, FileClock, Phone, Mail, FileCheck } from "lucide-react";
import { Product } from "../data";

interface RfqItem {
  product: Product;
  quantityValue: number;
  quantityUnit: string;
  packagingType: string;
}

interface HeaderProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
  rfqItems: RfqItem[];
  removeRfqItem: (id: string) => void;
  updateRfqItem: (id: string, qty: number, unit: string, pkg: string) => void;
  onOpenQuoteForm: () => void;
}

export default function Header({
  activeTab,
  setActiveTab,
  rfqItems,
  removeRfqItem,
  updateRfqItem,
  onOpenQuoteForm
}: HeaderProps) {
  const [isRfqOpen, setIsRfqOpen] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  // Quick helper to calculate total drafted cargo weight
  const totalWeightKg = rfqItems.reduce((acc, item) => {
    let multiplier = 1;
    if (item.quantityUnit === "Tons") multiplier = 1000;
    return acc + (item.quantityValue * multiplier);
  }, 0);

  const navLinks = [
    { id: "home", label: "Home" },
    { id: "products", label: "Ingredients & Catalog" },
    { id: "process", label: "Sourcing & Quality Code" },
    { id: "packaging", label: "Logistics & Packaging" },
    { id: "contact", label: "Trade Office" }
  ];

  return (
    <>
      {/* Top Professional B2B Utility Ticker */}
      <div className="w-full bg-[#1A1A1A] text-[11px] font-mono text-slate-300 font-medium py-1.5 px-4 md:px-8 flex flex-col sm:flex-row justify-between items-center border-b border-emerald-900/20 gap-2">
        <div className="flex items-center gap-4">
          <span className="flex items-center gap-1.5">
            <span className="w-1.5 h-1.5 bg-emerald-500 rounded-full animate-ping" />
            <span>EXPORT OFFICE DAILY LOGS: OPEN</span>
          </span>
          <span className="hidden md:inline text-slate-500">|</span>
          <span className="hidden md:inline">IEC: DAVPT2930Q</span>
          <span className="hidden md:inline text-slate-500">|</span>
          <span className="hidden md:inline">GST: 27DAVPT2930Q1ZK</span>
        </div>
        <div className="flex items-center gap-4 font-sans">
          <a href="mailto:kanhaiyaexim@yahoo.com" className="hover:text-[#D4A017] transition flex items-center gap-1">
            <Mail className="w-3.5 h-3.5 text-emerald-500" /> kanhaiyaexim@yahoo.com
          </a>
          <a href="tel:+919699265156" className="hover:text-[#D4A017] transition flex items-center gap-1">
            <Phone className="w-3.5 h-3.5 text-emerald-500" /> +91 9699265156
          </a>
        </div>
      </div>

      {/* Main Luxury Navigation Bar */}
      <header className="sticky top-0 z-40 w-full bg-white/95 backdrop-blur-md border-b border-emerald-950/10 shadow-xs">
        <div className="max-w-7xl mx-auto px-4 md:px-8 py-4 flex items-center justify-between">
          
          {/* Brand Identity: Premium Typography without Logo */}
          <button 
            onClick={() => { setActiveTab("home"); window.scrollTo({ top: 0, behavior: "smooth" }); }}
            className="flex items-center gap-1.5 group text-left cursor-pointer"
          >
            <span className="font-display font-extrabold text-2xl tracking-tight text-slate-900 group-hover:text-[#1F6B3A] transition">
              Kanhaiya<span className="text-[#1F6B3A] group-hover:text-[#D4A017] transition">Exim</span>
            </span>
            <span className="w-2 h-2 rounded-full bg-[#D4A017] animate-pulse self-end mb-2" title="Global Trade Anchor" />
          </button>

          {/* Large Screen Navigation Menu */}
          <nav className="hidden lg:flex items-center gap-1 xl:gap-2">
            {navLinks.map((link) => (
              <button
                key={link.id}
                id={`nav_link_${link.id}`}
                onClick={() => {
                  setActiveTab(link.id);
                  window.scrollTo({ top: 0, behavior: "smooth" });
                }}
                className={`px-4 py-2 text-[13px] font-sans font-medium rounded-xl transition ${
                  activeTab === link.id
                    ? "bg-[#1F6B3A]/10 text-[#1F6B3A]"
                    : "text-slate-600 hover:text-[#1F6B3A] hover:bg-emerald-50/50"
                }`}
              >
                {link.label}
              </button>
            ))}
          </nav>

          {/* Action Hub: Draft Sourcing RFQ & Quotes Buttons */}
          <div className="flex items-center gap-2.5">
            {/* RFQ Cargo Drawer Trigger */}
            <button
              id="rfq_cart_trigger"
              onClick={() => setIsRfqOpen(true)}
              className="relative p-2.5 rounded-xl border border-emerald-900/10 bg-emerald-50/20 text-emerald-900 hover:bg-emerald-50 hover:border-emerald-900/30 transition shadow-xs flex items-center justify-center cursor-pointer"
              title="View your drafted sourcing request list"
            >
              <ShoppingCart className="w-5 h-5 text-[#1F6B3A]" />
              {rfqItems.length > 0 && (
                <span className="absolute -top-1.5 -right-1.5 min-w-[20px] h-5 bg-[#D4A017] text-white text-[10px] font-bold font-mono px-1 rounded-full flex items-center justify-center shadow-xs animate-bounce">
                  {rfqItems.length}
                </span>
              )}
            </button>

            {/* Quick Multi-Sourcing Direct Call-To-Action */}
            <button
              id="it_quote_direct_btn"
              onClick={onOpenQuoteForm}
              className="hidden sm:inline-flex items-center gap-1.5 bg-[#1F6B3A] text-white hover:bg-emerald-800 text-xs font-semibold font-display tracking-wide uppercase px-5 py-3 rounded-xl shadow-xs hover:shadow-md transition cursor-pointer border-b border-emerald-950/20"
            >
              <FileCheck className="w-4 h-4 text-[#D4A017]" /> Request Quote
            </button>

            {/* Mobile Menu Icon */}
            <button
              onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
              className="lg:hidden p-2 rounded-xl text-slate-700 hover:bg-slate-100 transition"
              aria-label="Toggle menu"
            >
              <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                {isMobileMenuOpen ? (
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M6 18L18 6M6 6l12 12" />
                ) : (
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M4 6h16M4 12h16M4 18h16" />
                )}
              </svg>
            </button>
          </div>
        </div>

        {/* Mobile Navigation Dropdown Menu */}
        {isMobileMenuOpen && (
          <div className="lg:hidden border-t border-slate-100 bg-white shadow-lg animate-fade-in">
            <div className="px-4 py-3 space-y-1.5">
              {navLinks.map((link) => (
                <button
                  key={link.id}
                  onClick={() => {
                    setActiveTab(link.id);
                    setIsMobileMenuOpen(false);
                    window.scrollTo({ top: 0, behavior: "smooth" });
                  }}
                  className={`w-full text-left px-4 py-2.5 text-sm font-sans font-medium rounded-lg transition ${
                    activeTab === link.id
                      ? "bg-[#1F6B3A] text-white"
                      : "text-slate-700 hover:bg-emerald-50 hover:text-[#1F6B3A]"
                  }`}
                >
                  {link.label}
                </button>
              ))}
              <div className="pt-2 border-t border-slate-100 mt-2">
                <button
                  onClick={() => {
                    setIsMobileMenuOpen(false);
                    onOpenQuoteForm();
                  }}
                  className="w-full py-3 bg-[#1F6B3A] text-white text-center rounded-xl text-xs font-bold uppercase tracking-wide flex items-center justify-center gap-1.5"
                >
                  <FileCheck className="w-4 h-4 text-[#D4A017]" /> Request Quote
                </button>
              </div>
            </div>
          </div>
        )}
      </header>

      {/* Slide-out RFQ Drawer / Sourcing Draft Cart */}
      {isRfqOpen && (
        <div className="fixed inset-0 z-50 overflow-hidden" aria-labelledby="slide-over-title" role="dialog" aria-modal="true">
          <div className="absolute inset-0 bg-black/40 backdrop-blur-xs transition-opacity" onClick={() => setIsRfqOpen(false)} />

          <div className="absolute inset-y-0 right-0 max-w-full pl-10 flex">
            <div className="w-screen max-w-lg bg-white shadow-2xl flex flex-col h-full border-l border-emerald-900/10">
              
              {/* Drawer Header */}
              <div className="px-6 py-5 bg-[#1F6B3A] text-white flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <ShoppingCart className="w-5 h-5 text-[#D4A017]" />
                  <div>
                    <h3 className="text-base font-bold font-display tracking-tight">Sourcing Quotation Drawer</h3>
                    <p className="text-[11px] text-emerald-100/90 font-sans">Drafting RFQ container loads for KanhaiyaExim</p>
                  </div>
                </div>
                <button
                  onClick={() => setIsRfqOpen(false)}
                  className="p-1 rounded-full text-white/80 hover:text-white hover:bg-emerald-800 transition"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              {/* Drawer Body */}
              <div className="flex-1 overflow-y-auto px-6 py-4 space-y-4">
                {rfqItems.length === 0 ? (
                  <div className="h-64 flex flex-col items-center justify-center text-center space-y-4 px-4">
                    <div className="w-16 h-16 rounded-full bg-emerald-50 flex items-center justify-center text-[#1F6B3A] border border-emerald-900/5 shadow-inner">
                      <Briefcase className="w-8 h-8 text-emerald-700/60" />
                    </div>
                    <div>
                      <h4 className="text-sm font-semibold text-slate-800">Your Sourcing cart is empty</h4>
                      <p className="text-xs text-slate-500 max-w-[280px] mx-auto mt-1 leading-normal font-sans">
                        Browse our 70+ dehydrated powders categories, click "+ Sourcing Cart" to draft container targets, then submit details easily.
                      </p>
                    </div>
                    <button
                      onClick={() => {
                        setIsRfqOpen(false);
                        setActiveTab("products");
                      }}
                      className="px-4 py-2 bg-gradient-to-r from-[#1F6B3A] to-emerald-800 hover:to-emerald-700 text-white text-xs font-semibold rounded-lg shadow-xs"
                    >
                      Browse Ingredients
                    </button>
                  </div>
                ) : (
                  <>
                    <h4 className="text-xs font-mono font-bold tracking-wider text-slate-400 uppercase flex items-center gap-1.5">
                      <FileClock className="w-3.5 h-3.5 text-[#D4A017]" /> Current Custom Sourcing Order
                    </h4>
                    
                    <div className="space-y-3.5">
                      {rfqItems.map((item) => (
                        <div key={item.product.id} className="relative bg-[#F7F9F8] border border-emerald-900/10 rounded-2xl p-4 space-y-3 shadow-xs hover:border-emerald-950/20 transition">
                          
                          {/* Heading & Remover */}
                          <div className="flex justify-between items-start gap-3">
                            <div>
                              <h5 className="text-sm font-bold text-slate-900 font-sans">{item.product.name}</h5>
                              <p className="not-italic text-[10px] text-emerald-800 font-mono mt-0.5">ID: {item.product.id}</p>
                            </div>
                            <button
                              id={`remove_rfq_item_${item.product.id}`}
                              onClick={() => removeRfqItem(item.product.id)}
                              className="p-1 text-slate-400 hover:text-rose-600 rounded-lg hover:bg-rose-50 transition"
                              title="Remove item"
                            >
                              <Trash2 className="w-4 h-4" />
                            </button>
                          </div>

                          {/* Customization Inputs */}
                          <div className="grid grid-cols-2 gap-3 pt-2.5 border-t border-slate-200/60">
                            <div>
                              <label className="block text-[10px] font-mono text-slate-500 uppercase font-semibold mb-1">Target Quantity</label>
                              <div className="flex rounded-md shadow-xs bg-white border border-slate-300 overflow-hidden">
                                <input
                                  id={`rfq_qty_input_${item.product.id}`}
                                  type="number"
                                  min="10"
                                  value={item.quantityValue}
                                  onChange={(e) => updateRfqItem(item.product.id, Number(e.target.value), item.quantityUnit, item.packagingType)}
                                  className="w-full px-2 py-1 text-xs text-slate-900 font-semibold focus:outline-hidden"
                                />
                                <select
                                  id={`rfq_unit_select_${item.product.id}`}
                                  value={item.quantityUnit}
                                  onChange={(e) => updateRfqItem(item.product.id, item.quantityValue, e.target.value, item.packagingType)}
                                  className="bg-slate-100 text-[11px] font-sans font-medium text-slate-700 border-l border-slate-300 px-1 focus:outline-hidden"
                                >
                                  <option value="kg">kg</option>
                                  <option value="Tons">Tons</option>
                                </select>
                              </div>
                            </div>

                            <div>
                              <label className="block text-[10px] font-mono text-slate-500 uppercase font-semibold mb-1">Packaging Spec</label>
                              <select
                                id={`rfq_pkg_select_${item.product.id}`}
                                value={item.packagingType}
                                onChange={(e) => updateRfqItem(item.product.id, item.quantityValue, item.quantityUnit, e.target.value)}
                                className="w-full rounded-md shadow-xs bg-white border border-slate-300 text-xs px-2 py-1.5 text-slate-800 font-medium focus:ring-1 focus:ring-emerald-500 focus:outline-hidden"
                              >
                                <option value="25kg Bulk Bag">25kg Bulk Bag</option>
                                <option value="HDPE Drum Packaging">HDPE Drum</option>
                                <option value="5kg Food Box">5kg Box Packaging</option>
                                <option value="Retail Pouch (1kg)">Retail Pouch (1kg)</option>
                                <option value="Custom Private Label">Custom/Private Label</option>
                              </select>
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>

                    {/* Sourcing Summary Estimation */}
                    <div className="border-t border-dashed border-slate-300 pt-4 mt-6">
                      <div className="bg-[#1F6B3A]/5 border border-emerald-900/10 rounded-2xl p-4.5 space-y-2">
                        <div className="flex justify-between text-xs text-slate-600 font-sans">
                          <span>Total Items drafted:</span>
                          <span className="font-bold text-slate-800">{rfqItems.length} Products</span>
                        </div>
                        <div className="flex justify-between text-xs text-slate-600 font-sans">
                          <span>Est. Total Sourcing Weight:</span>
                          <span className="font-bold text-[#1F6B3A]">{totalWeightKg >= 1000 ? `${(totalWeightKg/1000).toFixed(2)} Tons` : `${totalWeightKg} kg`}</span>
                        </div>
                        <div className="flex justify-between text-xs text-slate-600 font-sans">
                          <span>Recommended Packing:</span>
                          <span className="font-bold text-[#D4A017]">
                            {totalWeightKg > 15000 ? "40ft Container (FCL)" : (totalWeightKg > 5000 ? "20ft Container (FCL)" : "LCL Shipment Group")}
                          </span>
                        </div>
                      </div>
                    </div>
                  </>
                )}
              </div>

              {/* Drawer Footer Actions */}
              {rfqItems.length > 0 && (
                <div className="px-6 py-5 border-t border-slate-100 bg-slate-50 space-y-3.5">
                  <p className="text-[11.5px] text-slate-500 leading-normal text-center font-sans">
                    These items will be seamlessly pre-filled into your final quotation request form automatically.
                  </p>
                  
                  <button
                    id="rfq_submit_to_form_btn"
                    onClick={() => {
                      setIsRfqOpen(false);
                      onOpenQuoteForm();
                    }}
                    className="w-full py-3.5 px-4 bg-gradient-to-r from-[#1F6B3A] to-emerald-950 hover:to-emerald-900 text-white rounded-xl text-sm font-bold font-display tracking-wide uppercase flex items-center justify-center gap-2 shadow-md hover:shadow-lg transition cursor-pointer"
                  >
                    <Ship className="w-4 h-4 text-[#D4A017]" /> Auto-Fill Inquiry Form
                  </button>
                </div>
              )}
            </div>
          </div>
        </div>
      )}
    </>
  );
}
