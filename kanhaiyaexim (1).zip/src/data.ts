/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export interface Product {
  id: string;
  name: string;
  description: string;
  benefits?: string[];
  applications?: string[];
}

export interface ProductGroup {
  id: string;
  name: string;
  description: string;
  icon: string; // Lucide icon name
  products: Product[];
}

export const PRODUCT_CATEGORIES: ProductGroup[] = [
  {
    id: "flagship",
    name: "Flagship Specialty",
    description: "Our signature, nutrient-dense export line cultivated in premium agricultural zones.",
    icon: "Crown",
    products: [
      {
        id: "moringa-leaf-powder-flagship",
        name: "Moringa Leaf Powder",
        description: "100% pure, vibrant green, fine-mesh Moringa oleifera powder. Sourced directly from sustainably managed farms, processed under optimal low temperature to lock in vital mineral profiles, vitamins, and antioxidants. Highly demanded by green supplement brands and nutraceutical manufacturers worldwide.",
        benefits: ["Rich in Vitamins A, C & E", "High bio-available iron and calcium", "Premium grade 120+ mesh size"],
        applications: ["Nutraceutical capsules", "Superfood smoothie blends", "Fortified food formulations"]
      }
    ]
  },
  {
    id: "vegetable-powders",
    name: "Dehydrated Vegetable Powders",
    description: "Premium grade vegetable powders processed using state-of-the-art dehydration to retain natural taste, colour, and nutrition.",
    icon: "Leaf",
    products: [
      { id: "garlic-powder", name: "Garlic Powder", description: "Sharp, pungent, and dry granulated powder from select premium Indian garlic cloves. Ideal for culinary seasonings, dry rubs, and food industries." },
      { id: "onion-powder-white", name: "Onion Powder White", description: "Premium quality white onion powder with sweet, savory characteristics. Perfect for soup bases, institutional culinary formulation, and snack flavorings." },
      { id: "onion-powder-red", name: "Onion Powder Red", description: "Robust and full-flavor red onion powder made from selected premium bulbs. Rich in organoleptic qualities suitable for premium B2B food applications." },
      { id: "beetroot-powder", name: "Beetroot Powder", description: "Rich, vivid maroon powder from fresh Beta vulgaris. Retains natural sweetness and high nitrogen content. Favored as a natural colorant and energy booster." },
      { id: "carrot-powder", name: "Carrot Powder", description: "Sweet carrot powder of premium grade rich in beta-carotene. Free-flowing powder used in infant foods, bakery mixes, and ready-to-eat products." },
      { id: "spinach-powder", name: "Spinach Powder", description: "Deep green, highly nutritious spinach leaf powder. Packed with chlorophyll and dietary fibers for health and dietary supplements." },
      { id: "tomato-powder", name: "Tomato Powder", description: "Standard high quality dehydrated tomato powder with deep red tone. Excellent acid-sweet balance for general manufacturing." },
      { id: "tomato-powder-premium", name: "Tomato Powder Premium", description: "Extra-fine, high-lycopene tomato powder prepared under strict hygienic conditions. Vibrant color and superb dispersion speed." },
      { id: "tomato-powder-rich", name: "Tomato Powder Rich", description: "Concentrated flavor-rich tomato powder providing an enhanced natural umami depth for gourmet sauces and soup formulas." },
      { id: "tomato-powder-a1", name: "Tomato Powder A1", description: "A-grade high density spray/drum-dried tomato powder. Exceptionally clean flavor profile and superior texture contribution to fine recipes." },
      { id: "tomato-powder-organic-shade", name: "Tomato Powder Organic Shade", description: "Artisanal-level organic shade dry inspired formulation. Preserves original enzymatic structures and raw plant attributes closely." },
      { id: "tomato-powder-tpm", name: "Tomato Powder TPM", description: "Tomato Powder TPM grade. Custom texture and dispersion properties engineered specifically for global commercial food processors." },
      { id: "tomato-powder-tps", name: "Tomato Powder TPS", description: "Tomato Powder TPS standard. Developed for dry soup mixes and ready-to-use gravies requiring rapid reconstitution." },
      { id: "tomato-powder-ab30", name: "Tomato Powder AB30", description: "Elite-grade high color value powder with exceptional solid consistency, specifically structured for bulk industrial formulation." },
      { id: "cucumber-powder", name: "Cucumber Powder", description: "Crisp, cooling, and refreshingly fragrant cucumber powder. Premium grade for beauty care, nutraceutical formats, and healthy beverages." },
      { id: "pumpkin-powder", name: "Pumpkin Powder", description: "Rich orange, nutrient-dense pumpkin powder. Excellent natural thickener and flavor enhancer containing wholesome dietary value." },
      { id: "potato-powder", name: "Potato Powder", description: "Pure dehydrated potato solids. Essential binder, texturizer, and thickener for soups, bakery, extruded snacks, and frozen foods." },
      { id: "green-chilli-powder", name: "Green Chilli Powder", description: "Sharp, spicy, and naturally green spice kick made from fresh Indian hot peppers. Free-flowing seasoning grade." },
      { id: "ginger-powder", name: "Ginger Powder", description: "Finest sun-dried and dehydrated ginger root powder. Warm, spicy, aromatic notes with high gingerol content. Standard export grade." },
      { id: "coriander-leaf-powder", name: "Coriander Leaf Powder", description: "Bright green coriander (cilantro) leaves dried and milled into a highly aromatic seasoning ideal for premium herbal teas and blends." },
      { id: "bitter-gourd-powder", name: "Bitter Gourd Powder", description: "Pure bitter melon powder of uniform mesh size, highly regarded for blood sugar regulation formulations in the nutra-supplement market." }
    ]
  },
  {
    id: "fruit-powders",
    name: "Natural Fruit Powders",
    description: "Vibrant, full-flavored powders from choice Indian orchards. Spray dried or freeze dried to capture standard flavor concentration.",
    icon: "Apple",
    products: [
      { id: "mango-powder-alphonso", name: "Mango Powder Alphonso", description: "Made from premium 'King of Mangoes' Alphonso varieties. Elite-grade color, aroma, and luxurious tropical taste profile for luxury dessert and drink formulations." },
      { id: "mango-powder-regular", name: "Mango Powder Regular", description: "Standard ripe mango powder capturing delightful, sweet tropical notes. Versatile application in baking and dairy formulations." },
      { id: "mango-powder-unripe", name: "Mango Powder Unripe (Amchur alternative)", description: "Sour, tangy unripe mango powder. Essential acidifying agent used for savory snack dustings and Indian spice mixes." },
      { id: "banana-powder", name: "Banana Powder", description: "Rich, sweet, and highly soluble ripe banana powder. High potassium content, excellent base for instant infant porridges and protein shakes." },
      { id: "pineapple-powder", name: "Pineapple Powder", description: "Tangy-sweet yellow powder from select pineapples. High bromelain enzyme content, fine solubility in beverages." },
      { id: "papaya-powder", name: "Papaya Powder (Ripe)", description: "Delightful ripe papaya powder. Rich in papain, vitamins, and beautiful natural orange hue." },
      { id: "papaya-unripe-powder", name: "Papaya Unripe Powder", description: "Green unripe papaya powder. Widely sourced globally as a potent natural meat tenderizer and raw digestive enzyme base." },
      { id: "lemon-powder", name: "Lemon Powder", description: "Zesty, refreshing spray-dried lemon powder with standard citric punch. Highly dry-mix friendly." },
      { id: "lemon-powder-premium", name: "Lemon Powder Premium", description: "Premium grade using high-juice solids. Excellent fresh aroma and instantaneous cold-water dispersion." },
      { id: "lemon-powder-rich", name: "Lemon Powder Rich", description: "Intensively sour and concentrated lemon powder with enhanced peel oil aroma profiles for gourmet food industries." },
      { id: "lemon-powder-a1", name: "Lemon Powder A1", description: "A1 standard clean-label lemon powder with zero anti-caking additives. Pure citrus refreshment for organic-certified exports." },
      { id: "orange-powder", name: "Orange Powder", description: "Vibrant orange citrus powder. Packed with high Vitamin C and fresh zest aroma for dietary powders and RTD beverages." },
      { id: "pomegranate-powder", name: "Pomegranate Powder", description: "Deep ruby red powder made from prime Indian pomegranates. Exceptional antioxidant and polyphenol carrier." },
      { id: "pink-guava-powder", name: "Pink Guava Powder", description: "Aromatic pink guava powder, featuring exquisite floral-fruity notes and beautiful pastel pink color output." },
      { id: "white-guava-powder", name: "White Guava Powder", description: "Delicate and sweet white guava powder. Widely used in tropical nectar production and exotic confectionery." },
      { id: "watermelon-powder", name: "Watermelon Powder", description: "Refreshing, highly soluble watermelon powder capturing the crisp summer beverage demand." },
      { id: "mulberry-powder", name: "Mulberry Powder", description: "Rare premium dark mulberry powder with rich anthocyanin content. Favored by natural well-being and health supplement developers." },
      { id: "strawberry-powder", name: "Strawberry Powder", description: "Sweet, authentic pink strawberry powder. Ideal for milkshakes, ice creams, wellness supplements, and bakery icing." },
      { id: "raspberry-powder", name: "Raspberry Powder", description: "Fine red fruit powder with intense tart note and characteristic red berry flavor profile for high-end food products." },
      { id: "cherry-powder", name: "Cherry Powder", description: "Rich cherry powder containing essential phytonutrients. Perfect for premium functional beverages and energy formulations." }
    ]
  },
  {
    id: "herbal-powders",
    name: "Herbal & Leaf Powders",
    description: "Sustainably harvested botanicals and leafy greens processed under hygienic standards to meet safety values of global nutraceutical buyers.",
    icon: "Activity",
    products: [
      { id: "moringa-powder", name: "Moringa Powder", description: "Standard nutrient-dense Moringa oleifera leaf powder, finely milled (80-100 mesh) for clean encapsulation and tea infusions." },
      { id: "mint-powder", name: "Mint Powder", description: "Cooling, intensely aromatic mint leaf (Pudina) powder. Exceptional quality for seasoning, functional teas, and cooling food mixes." },
      { id: "neem-powder", name: "Neem Powder", description: "100% pure bitter Azadirachta indica leaf powder. Acclaimed global organic pesticide ingredient, custom wellness capsule ingredient, and cosmetic detox component." },
      { id: "curry-leaf-powder", name: "Curry Leaf Powder", description: "Fragrant and antioxidant-rich curry leaf powder. Enhances digestives and typical Asian seasoning profiles with high culinary value." }
    ]
  },
  {
    id: "spice-specialty",
    name: "Spice & Specialty Powders",
    description: "Specialized agricultural ingredients, acidulants, and spray-dried flavors designed for custom dry food manufacturing recipes.",
    icon: "Award",
    products: [
      { id: "tamarind-powder", name: "Tamarind Powder", description: "Tangy, sour dehydrated pulp of fresh Indian tamarind. Ideal seasoning base for institutional soups and Asian cooking pastes." },
      { id: "tamarind-powder-premium", name: "Tamarind Powder Premium", description: "Extra refined, high-solubility tamarind powder with zero heavy fiber residue. Instant culinary dissolution." },
      { id: "tamarind-powder-rich", name: "Tamarind Powder Rich", description: "Delectably tart and sticky-note high-density tamarind powder, perfect for snack coating dust and dry sauces." },
      { id: "honey-powder", name: "Honey Powder", description: "Free-flowing premium honey powder. Offers authentic, natural sweetness of pure honey without the standard liquid handling hurdles." },
      { id: "vinegar-powder", name: "Vinegar Powder", description: "White distilled vinegar converted into premium free-flowing powder form. Excellent for extreme tang in chips, dry dips, and glazes." },
      { id: "soya-sauce-powder", name: "Soya Sauce Powder", description: "Spray-dried naturally fermented soy sauce. Delivers strong, authentic savory-umami depth in a dry carrier." },
      { id: "cara-soya-powder", name: "Cara Soya Powder", description: "Specialized protein-rich custom soy extract powder formulated for industrial binding and vegetarian texturizing." },
      { id: "caramel-powder", name: "Caramel Powder", description: "Rich, sweet, dark-brown caramel powder offering luxurious caramelized sugar and roasted butter notes." },
      { id: "chicory-powder", name: "Chicory Powder", description: "Roasted and ground custom chicory root powder. Naturally caffeine-free beverage base with rich, prebiotic inulin dietary fiber." },
      { id: "amchur-powder", name: "Amchur Powder", description: "Traditional dried green mango powder. High-quality dry souring agent with a fruity undertone." }
    ]
  },
  {
    id: "tea-coffee",
    name: "Tea & Coffee Powders",
    description: "Highly soluble premium spray-dried hot and cold extracts of real Indian tea estates and Western Ghats coffee beans.",
    icon: "Coffee",
    products: [
      { id: "black-tea-hot", name: "Black Tea Powder Hot Water Soluble", description: "Instant hot water soluble black tea powder. Yields a rich amber liquor with full-bodied tannic satisfaction, perfect for ready-mix chains." },
      { id: "black-tea-cold", name: "Black Tea Powder Cold Water Soluble", description: "Quick cold-water dispersing instant black tea powder. Crystal clear solubility with zero cloudiness, highly demanded for canned iced teas." },
      { id: "instant-tea", name: "Instant Tea Powder", description: "Finely parsed basic instant tea extract. Balanced body, optimized for quick automatic vending machines and private label packaging." },
      { id: "coffee-pure", name: "Coffee Powder 100% Pure", description: "100% premium spray-dried instant coffee powder. Sourced from high-grown Robusta & Arabica, providing standard rich aroma and dark crema." },
      { id: "coffee-chicory-70", name: "Coffee Powder with Chicory 70:30", description: "Classic traditional blend containing 70% pure spray-dried coffee and 30% premium chicory. Rich, dark color and intensive lingering robust taste." },
      { id: "coffee-chicory-50", name: "Coffee Powder with Chicory 50:50", description: "Equally balanced 50% coffee and 50% roasted chicory blend, highly favored for strong traditional milk recipes and budget private-labels." },
      { id: "spray-tea-sd", name: "Spray Dried Tea Powder", description: "Fine-grade spray-dried tea solids with customized extraction metrics, perfect for ready-to-mix iced tea formulations." },
      { id: "spray-coffee-sd", name: "Spray Dried Coffee Powder", description: "Premium spray-dried soluble coffee offering instantaneous reconstitution and exceptionally clean shelf-stability." }
    ]
  }
];

export const CUSTOM_SERVICES = [
  {
    title: "Private Label Packaging",
    description: "Launch your own brand effortlessly. We offer end-to-end retail packaging in stand-up pouches, jars, tin cans, or boxes with your visual branding.",
    icon: "Package"
  },
  {
    title: "Contract Manufacturing",
    description: "Partner with our state-of-the-art facilities for high-volume contract drying, milling, blending, sifting, and custom mesh adjustments.",
    icon: "Settings"
  },
  {
    title: "Custom Product Blends",
    description: "Our in-house agricultural chemists formulate buyer-specific powder blends, custom nutrient ratios, and specialized flavor parameters.",
    icon: "Flame"
  },
  {
    title: "OEM Solutions & Bulk Supply",
    description: "Reliable large-scale shipments customized in heavy-duty HDPE drums, laminated bags, or secure fiber boxes aligned with standard customs procedures.",
    icon: "Truck"
  }
];

export const WHY_CHOOSE_US_ITEMS = [
  { title: "Trusted Indian Sourcing", desc: "Direct partnerships with growers in major fertile agro-climatic zones like Nashik, ensuring peak quality agricultural yield." },
  { title: "Merchant Export Expertise", desc: "Expert navigation of international rules, strict compliance, bilateral certificates, phytosanitary requirements, and customs clearances." },
  { title: "Reliable Processing Partners", desc: "Our processing associates run clean facilities equipped with premium dehydrators, high-speed pulverizers, and metal detectors." },
  { title: "Export Documentation Support", desc: "We handle clean-audit bills of lading, COO (Certificate of Origin), phytosanitary certificates, SGS reports, and customized customs invoices." },
  { title: "Quality-Focused Procurement", desc: "Rigorous incoming evaluation of agricultural raw products. Only moisture-conforming, pesticide-compliant batches enter our line." },
  { title: "Flexible MOQ & Private Label", desc: "Supporting growth of regional and global brands with flexible, low Minimum Order Quantity (MOQ) start points and retail packaging setup." },
  { title: "Global Logistics Coordination", desc: "Ocean and air freight coordination through trusted global shipping liners, guaranteeing container safety from JNPT (Nhava Sheva) or Mumbai ports." },
  { title: "Transparent Communication", desc: "Direct, fast responses, real-time cargo status updates, and professional WhatsApp/Email business standards." }
];

export const QA_STEPS = [
  { phase: "01", name: "Raw Material Verification", desc: "Visual color check, pesticide residual assessment, and moisture balance inspection of harvested ingredients." },
  { phase: "02", name: "Supplier Evaluation", desc: "Partner processing facilities are vetted for ISO, FSSAI, HACCP, or organic-conformance standards." },
  { phase: "03", name: "Processing Verification", desc: "Control of temperature fields during dehydration to prevent product scorching and preserve volatile oils/organics." },
  { phase: "04", name: "Quality Inspection", desc: "Multi-stage physical testing: mesh size uniformity (100-120 mesh), metal detection scan, and microbial evaluation." },
  { phase: "05", name: "Packaging Inspection", desc: "Checking seal integrity of primary heavy-duty polybags and food-grade barrier liners inside final cargo boxes." },
  { phase: "06", name: "Documentation Verification", desc: "Creation of professional Phytosanitary, Certificate of Analysis (COA), packing lists, and correct HS codes." },
  { phase: "07", name: "Shipment Approval", desc: "Secure container loading inspection at our yard prior to transport to logistics hubs. Handover of digital pictures to buyer." }
];

export const PACKAGING_SIZES = ["100g", "250g", "500g", "1kg", "5kg", "10kg", "20kg", "25kg"];

export const PACKAGING_TYPES = [
  { title: "Bulk Packaging", desc: "Heavy-duty HDPE drums, multi-layer Kraft paper sacks, or durable inner poly-lined woven sacks for maximum transport protection." },
  { title: "Private Label Packaging", desc: "Premium stand-up zipper pouches, glass jars, tin containers, or custom printed boxes tailored with your brand asset files." },
  { title: "Food Grade Certification", desc: "100% certified food-grade packaging materials, preserving volatile flavor notes and completely locking out unwanted air or moisture." },
  { title: "Export Strength Shielding", desc: "Reinforced 5-ply cartons, oxygen absorbers, moisture desiccants, and security-banded palletization for absolute long-haul maritime protection." }
];

export const MARKETS_WE_SERVE = [
  { id: "germany", name: "Germany", lat: 51.1657, lng: 10.4515, label: "Frankfurt Hub (EU Distribution)" },
  { id: "uk", name: "United Kingdom", lat: 55.3781, lng: -3.4360, label: "London Gateway (Trade Specialist)" },
  { id: "usa", name: "United States", lat: 37.0902, lng: -95.7129, label: "New York/LA Ports (High Volume Bulk)" },
  { id: "canada", name: "Canada", lat: 56.1304, lng: -106.3468, label: "Toronto/Vancouver (Nutraceuticals)" },
  { id: "australia", name: "Australia", lat: -25.2744, lng: 133.7751, label: "Sydney Harbour (Superfoods Focus)" },
  { id: "uae", name: "UAE / Middle East", lat: 23.4241, lng: 53.8478, label: "Jebel Ali Port (Re-Export Center)" },
  { id: "europe", name: "Continental Europe", lat: 46.2276, lng: 2.2137, label: "Rotterdam Ingress (Ingredient Wholesale)" }
];

export const TARGET_BUYERS = [
  { name: "Importers", desc: "Seeking reliable agricultural suppliers with compliant documentation and constant pricing grids." },
  { name: "Raw Ingredient Traders", desc: "Requiring consistent large tonnage output, standardized specifications, and secure container shipping." },
  { name: "Food Manufacturers", desc: "Demanding custom-milled mesh uniformity, steady bacteriological safety, and prompt raw component delivery." },
  { name: "Nutraceutical Brands", desc: "Requiring organic purity, high active ingredient markers, and rigorous third-party lab testing sheets (COA)." },
  { name: "Private Label Brands", desc: "Needing swift turn-key packaging solutions, food-safe consumer packs, and custom-designed brand prints." },
  { name: "Supermarkets & Retail Chains", desc: "Looking for direct sourcing savings, shelf-stable premium materials, and certified food-safe standards." }
];

export const REVIEWS = [
  { quote: "KanhaiyaExim solved our supply bottlenecks for premium Moringa powder. Their quality control process is thorough and their documentation flawless.", author: "Dr. Marcus Weber", role: "Procurement Director, BioNutra GmbH", country: "Germany" },
  { quote: "As fruit powder importers, container moisture is always our biggest risk. KanhaiyaExim's dual-barrier bulk packing keep our dry mango powders absolutely fresh.", author: "Sarah Jenkins", role: "Sourcing Head, Horizon Food Group", country: "United Kingdom" },
  { quote: "Outstanding responsiveness! Abhijeet and his team replied within minutes with clear technical sheets (COA) for Red Onion and Tomato Powders.", author: "Nour Al-Sabah", role: "Manager, Gulf Ingredients Trading", country: "UAE" }
];

export const FAQS = [
  {
    q: "Are samples available for international evaluation?",
    a: "Yes. We arrange prompt product samples (typically 50g–100g) of any vegetable, fruit, or herbal powder. We dispatch these globally via express air couriers (DHL/FedEx). Sample products are free of charge; we only request the buyer to cover the courier cost or share their shipping account number."
  },
  {
    q: "What is your Minimum Order Quantity (MOQ)?",
    a: "Standard export bulk MOQ is 250 kg per product (typically consisting of 10 individual 25kg bags or drums). However, we support growing private label brands and niche importers, and can offer special test trials of 100 kg under custom agreements."
  },
  {
    q: "Can you customize mesh sizes or prepare specialized ingredient formulas?",
    a: "Yes. Our partner manufacturers use adjustive pulverizers allowing us to mill powders from standard coarse flakes up to super-fine 120-mesh specifications. We also offer customized agricultural mixes and custom ratio formulations."
  },
  {
    q: "Do you supply customized Private Label retail packaging?",
    a: "Absolutely. We provide comprehensive OEM/private labeling services. We package in retail-ready stand-up foil pouches (100g, 250g, 500g, 1kg), food jars, and cardboard packets, fully labeled and printed with your custom branding designs."
  },
  {
    q: "What standard shipping and payment terms do you offer?",
    a: "We support standard International Chamber of Commerce Incoterms: FOB (Free On Board, Nhava Sheva/JNPT Mumbai or Chennai port), CFR (Cost and Freight), and CIF (Cost, Insurance & Freight to your target sea port). Payment terms are generally structured as: 30% advance via T/T bank wire transfer, and 70% against clean digital copy of the Bill of Lading (B/L) and documents."
  },
  {
    q: "Which global markets and ports do you regularly export to?",
    a: "We focus on key food import hubs in Germany, the United Kingdom, broader Continental Europe, the USA, Canada, Australia, and Middle East destination ports like Jebel Ali (Dubai)."
  }
];
